import { useEffect } from "react";
import { Routes, Route, Navigate } from "react-router-dom";
import { Loader2 } from "lucide-react";
import { useAuthStore } from "./store/auth.store";

import Layout from "./components/layout/Layout";
import Login from "./pages/Login";
import ServerList from "./pages/ServerList";
import NewServer from "./pages/NewServer";
import Nodes from "./pages/Nodes";
import ApiKeys from "./pages/ApiKeys";
import Users from "./pages/Users";

import ServerWorkspace from "./pages/server/ServerWorkspace";
import ServerConsole from "./pages/server/ServerConsole";
import FileManager from "./pages/server/FileManager";
import PlayerManager from "./pages/server/PlayerManager";
import PluginStore from "./pages/server/PluginStore";
import WorldManager from "./pages/server/WorldManager";
import Tunneling from "./pages/server/Tunneling";
import SubUsers from "./pages/server/SubUsers";

function ProtectedRoutes() {
  const { user, isLoading, hydrate } = useAuthStore();

  useEffect(() => {
    hydrate();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  if (isLoading) {
    return (
      <div className="flex h-screen items-center justify-center">
        <Loader2 className="animate-spin text-slate-600" size={24} />
      </div>
    );
  }

  if (!user) return <Navigate to="/login" replace />;

  return (
    <Routes>
      <Route element={<Layout />}>
        <Route index element={<ServerList />} />
        <Route path="servers" element={<ServerList />} />
        <Route path="servers/new" element={<NewServer />} />
        <Route path="servers/:id" element={<ServerWorkspace />}>
          <Route index element={<Navigate to="console" replace />} />
          <Route path="console" element={<ServerConsole />} />
          <Route path="files" element={<FileManager />} />
          <Route path="players" element={<PlayerManager />} />
          <Route path="plugins" element={<PluginStore />} />
          <Route path="world" element={<WorldManager />} />
          <Route path="tunnel" element={<Tunneling />} />
          <Route path="access" element={<SubUsers />} />
        </Route>
        <Route path="nodes" element={<Nodes />} />
        <Route path="users" element={<Users />} />
        <Route path="api-keys" element={<ApiKeys />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default function App() {
  return (
    <Routes>
      <Route path="/login" element={<Login />} />
      <Route path="/*" element={<ProtectedRoutes />} />
    </Routes>
  );
}

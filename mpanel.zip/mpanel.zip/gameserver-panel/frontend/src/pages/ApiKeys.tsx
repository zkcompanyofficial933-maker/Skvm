import { useEffect, useState } from "react";
import { KeyRound, Plus, Trash2, Copy, Check } from "lucide-react";
import { api } from "../lib/api";
import Button from "../components/ui/Button";
import Modal from "../components/ui/Modal";
import { PERMISSIONS } from "../types";
import type { ApiKeyRecord, Permission } from "../types";

export default function ApiKeys() {
  const [keys, setKeys] = useState<ApiKeyRecord[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [name, setName] = useState("");
  const [scopes, setScopes] = useState<Set<Permission>>(new Set());
  const [rawKey, setRawKey] = useState<string | null>(null);
  const [copied, setCopied] = useState(false);

  function load() {
    api.get("/api-keys").then((r) => setKeys(r.data.keys));
  }
  useEffect(load, []);

  async function createKey() {
    const { data } = await api.post("/api-keys", { name, scopes: [...scopes] });
    setRawKey(data.rawKey);
    setModalOpen(false);
    setName("");
    setScopes(new Set());
    load();
  }

  async function revoke(id: string) {
    if (!confirm("Revoke this API key? Any integration using it will stop working immediately.")) return;
    await api.delete(`/api-keys/${id}`);
    load();
  }

  function toggleScope(p: Permission) {
    setScopes((prev) => {
      const next = new Set(prev);
      next.has(p) ? next.delete(p) : next.add(p);
      return next;
    });
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-slate-100">API Keys</h1>
          <p className="mt-1 text-sm text-slate-500">Generate scoped tokens for external integrations and automation.</p>
        </div>
        <Button onClick={() => setModalOpen(true)}>
          <Plus size={16} /> Generate key
        </Button>
      </div>

      {keys.length === 0 ? (
        <div className="glass rounded-xl p-10 text-center text-sm text-slate-500">No API keys yet.</div>
      ) : (
        <div className="glass divide-y divide-white/5 overflow-hidden rounded-xl">
          {keys.map((k) => (
            <div key={k.id} className="flex items-center justify-between px-4 py-3">
              <div className="flex items-center gap-3">
                <KeyRound size={16} className="text-accent-hover" />
                <div>
                  <p className="text-sm font-medium text-slate-100">{k.name}</p>
                  <p className="font-mono text-xs text-slate-500">{k.keyPrefix}••••••••••••••••</p>
                </div>
              </div>
              <div className="flex items-center gap-3">
                <span className="text-xs text-slate-600">{k.scopes.length} scopes</span>
                <button onClick={() => revoke(k.id)} className="rounded-md p-2 text-slate-500 hover:bg-white/5 hover:text-red-400">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Generate API key" width="max-w-xl">
        <div className="space-y-4">
          <div>
            <label className="mb-1 block text-xs text-slate-500">Key name</label>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="CI deployment key"
              className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-100 outline-none focus:border-accent/50"
            />
          </div>
          <div>
            <label className="mb-2 block text-xs text-slate-500">Scopes</label>
            <div className="grid max-h-56 grid-cols-2 gap-1 overflow-y-auto rounded-lg border border-white/5 p-2">
              {PERMISSIONS.map((p) => (
                <label key={p} className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm text-slate-300 hover:bg-white/5">
                  <input type="checkbox" checked={scopes.has(p)} onChange={() => toggleScope(p)} className="rounded border-white/20 bg-base-800 text-accent" />
                  {p}
                </label>
              ))}
            </div>
          </div>
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button onClick={createKey}>Generate</Button>
          </div>
        </div>
      </Modal>

      <Modal open={!!rawKey} onClose={() => setRawKey(null)} title="Your new API key">
        <div className="space-y-3">
          <p className="text-sm text-slate-400">Copy this key now — for security, it won't be shown again.</p>
          <div className="flex items-center gap-2">
            <code className="flex-1 break-all rounded-lg bg-base-950 p-3 text-xs text-accent-hover">{rawKey}</code>
            <button
              onClick={() => {
                navigator.clipboard.writeText(rawKey ?? "");
                setCopied(true);
                setTimeout(() => setCopied(false), 1500);
              }}
              className="rounded-lg bg-white/5 p-3 hover:bg-white/10"
            >
              {copied ? <Check size={14} /> : <Copy size={14} />}
            </button>
          </div>
          <Button className="w-full" onClick={() => setRawKey(null)}>Done</Button>
        </div>
      </Modal>
    </div>
  );
}

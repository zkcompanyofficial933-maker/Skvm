import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { Sparkles, Loader2 } from "lucide-react";
import { api } from "../lib/api";
import Button from "../components/ui/Button";
import type { HostNode } from "../types";

// itzg/minecraft-server is the de-facto standard Docker image for Minecraft hosting —
// a single image handles every server software via the TYPE env var.
const TEMPLATES = [
  { id: "VANILLA", label: "Vanilla", description: "Official Mojang server, no mods or plugins." },
  { id: "PAPER", label: "Paper", description: "High-performance fork with a plugin API. Most popular choice." },
  { id: "SPIGOT", label: "Spigot", description: "Plugin-compatible, CraftBukkit-based server." },
  { id: "FABRIC", label: "Fabric", description: "Lightweight modding platform." },
  { id: "FORGE", label: "Forge", description: "The classic modding platform for heavier modpacks." },
  { id: "PURPUR", label: "Purpur", description: "Paper fork with extra gameplay features & config options." },
];

const MC_VERSIONS = ["1.21.1", "1.20.6", "1.20.1", "1.19.4", "1.18.2", "1.16.5"];

export default function NewServer() {
  const navigate = useNavigate();
  const [nodes, setNodes] = useState<HostNode[]>([]);
  const [step, setStep] = useState(1);
  const [creating, setCreating] = useState(false);

  const [form, setForm] = useState({
    name: "",
    template: "PAPER",
    version: "1.21.1",
    nodeId: "",
    memoryLimitMb: 4096,
    cpuLimitCores: 2,
    diskLimitMb: 10000,
    primaryPort: 25565,
  });

  useEffect(() => {
    api.get("/nodes").then((r) => {
      setNodes(r.data.nodes);
      if (r.data.nodes[0]) setForm((f) => ({ ...f, nodeId: r.data.nodes[0].id }));
    });
  }, []);

  async function create() {
    setCreating(true);
    try {
      const { data } = await api.post("/servers", {
        name: form.name,
        nodeId: form.nodeId,
        image: "itzg/minecraft-server",
        dockerImageTag: "latest",
        memoryLimitMb: form.memoryLimitMb,
        cpuLimitCores: form.cpuLimitCores,
        diskLimitMb: form.diskLimitMb,
        startupCommand: "", // itzg image manages startup internally based on env vars
        environment: {
          EULA: "TRUE",
          TYPE: form.template,
          VERSION: form.version,
          MEMORY: `${form.memoryLimitMb}M`,
        },
        primaryPort: form.primaryPort,
        additionalPorts: [],
      });
      navigate(`/servers/${data.server.id}/console`);
    } finally {
      setCreating(false);
    }
  }

  return (
    <div className="mx-auto max-w-2xl space-y-6">
      <div>
        <h1 className="text-xl font-semibold text-slate-100">Create a new Minecraft server</h1>
        <p className="mt-1 text-sm text-slate-500">Provisioned instantly in an isolated Docker container.</p>
      </div>

      <div className="flex gap-1">
        {[1, 2, 3].map((s) => (
          <div key={s} className={`h-1 flex-1 rounded-full ${s <= step ? "bg-accent" : "bg-base-750"}`} />
        ))}
      </div>

      {step === 1 && (
        <div className="glass space-y-4 rounded-xl p-5">
          <div>
            <label className="mb-1 block text-xs text-slate-500">Server name</label>
            <input
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="My Survival World"
              className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-accent/50"
            />
          </div>
          <div>
            <label className="mb-2 block text-xs text-slate-500">Server software</label>
            <div className="grid grid-cols-2 gap-2">
              {TEMPLATES.map((t) => (
                <button
                  key={t.id}
                  onClick={() => setForm({ ...form, template: t.id })}
                  className={`rounded-lg border p-3 text-left transition-colors ${
                    form.template === t.id ? "border-accent/50 bg-accent/10" : "border-white/5 bg-base-800/60 hover:border-white/10"
                  }`}
                >
                  <p className="text-sm font-medium text-slate-100">{t.label}</p>
                  <p className="mt-0.5 text-xs text-slate-500">{t.description}</p>
                </button>
              ))}
            </div>
          </div>
          <div>
            <label className="mb-1 block text-xs text-slate-500">Minecraft version</label>
            <select
              value={form.version}
              onChange={(e) => setForm({ ...form, version: e.target.value })}
              className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2.5 text-sm text-slate-200"
            >
              {MC_VERSIONS.map((v) => (
                <option key={v} value={v}>{v}</option>
              ))}
            </select>
          </div>
          <div className="flex justify-end">
            <Button onClick={() => setStep(2)} disabled={!form.name}>Next: Resources</Button>
          </div>
        </div>
      )}

      {step === 2 && (
        <div className="glass space-y-4 rounded-xl p-5">
          <div>
            <label className="mb-1 block text-xs text-slate-500">Host node</label>
            <select
              value={form.nodeId}
              onChange={(e) => setForm({ ...form, nodeId: e.target.value })}
              className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2.5 text-sm text-slate-200"
            >
              {nodes.map((n) => (
                <option key={n.id} value={n.id}>{n.name} ({n.fqdn})</option>
              ))}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-3">
            <NumField label="Memory (MB)" value={form.memoryLimitMb} onChange={(v) => setForm({ ...form, memoryLimitMb: v })} />
            <NumField label="CPU cores" value={form.cpuLimitCores} onChange={(v) => setForm({ ...form, cpuLimitCores: v })} step={0.5} />
            <NumField label="Disk (MB)" value={form.diskLimitMb} onChange={(v) => setForm({ ...form, diskLimitMb: v })} />
            <NumField label="Server port" value={form.primaryPort} onChange={(v) => setForm({ ...form, primaryPort: v })} />
          </div>
          <div className="flex justify-between">
            <Button variant="secondary" onClick={() => setStep(1)}>Back</Button>
            <Button onClick={() => setStep(3)}>Next: Review</Button>
          </div>
        </div>
      )}

      {step === 3 && (
        <div className="glass space-y-4 rounded-xl p-5">
          <div className="flex items-center gap-2 text-accent-hover">
            <Sparkles size={16} />
            <p className="text-sm font-medium">Ready to deploy</p>
          </div>
          <dl className="space-y-2 text-sm">
            <Row label="Name" value={form.name} />
            <Row label="Software" value={`${form.template} ${form.version}`} />
            <Row label="Resources" value={`${form.memoryLimitMb}MB RAM · ${form.cpuLimitCores} vCPU · ${form.diskLimitMb}MB disk`} />
            <Row label="Port" value={String(form.primaryPort)} />
          </dl>
          <div className="flex justify-between">
            <Button variant="secondary" onClick={() => setStep(2)}>Back</Button>
            <Button onClick={create} disabled={creating}>
              {creating ? <Loader2 size={14} className="animate-spin" /> : "Deploy server"}
            </Button>
          </div>
        </div>
      )}
    </div>
  );
}

function NumField({ label, value, onChange, step = 1 }: { label: string; value: number; onChange: (v: number) => void; step?: number }) {
  return (
    <div>
      <label className="mb-1 block text-xs text-slate-500">{label}</label>
      <input
        type="number"
        step={step}
        value={value}
        onChange={(e) => onChange(Number(e.target.value))}
        className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-100 outline-none focus:border-accent/50"
      />
    </div>
  );
}

function Row({ label, value }: { label: string; value: string }) {
  return (
    <div className="flex justify-between border-b border-white/5 py-2">
      <dt className="text-slate-500">{label}</dt>
      <dd className="text-slate-200">{value}</dd>
    </div>
  );
}

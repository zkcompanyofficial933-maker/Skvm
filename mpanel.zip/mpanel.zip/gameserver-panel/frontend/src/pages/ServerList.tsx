import { useEffect, useMemo, useState } from "react";
import { Link } from "react-router-dom";
import { LayoutGrid, List, Cpu, MemoryStick, Server as ServerIcon, Plus } from "lucide-react";
import { api } from "../lib/api";
import StatusPill from "../components/ui/StatusPill";
import Button from "../components/ui/Button";
import type { GameServer } from "../types";

export default function ServerList() {
  const [servers, setServers] = useState<GameServer[]>([]);
  const [loading, setLoading] = useState(true);
  const [view, setView] = useState<"grid" | "list">("grid");

  useEffect(() => {
    api
      .get("/servers")
      .then((r) => setServers(r.data.servers))
      .finally(() => setLoading(false));
  }, []);

  const summary = useMemo(() => {
    const totalMemory = servers.reduce((sum, s) => sum + s.memoryLimitMb, 0);
    const running = servers.filter((s) => s.status === "RUNNING").length;
    return { totalMemory, running, total: servers.length };
  }, [servers]);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-slate-100">Dashboard</h1>
          <p className="mt-1 text-sm text-slate-500">An overview of every server across your infrastructure.</p>
        </div>
        <Link to="/servers/new">
          <Button>
            <Plus size={16} /> New server
          </Button>
        </Link>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
        <SummaryCard icon={ServerIcon} label="Active containers" value={`${summary.running} / ${summary.total}`} />
        <SummaryCard icon={MemoryStick} label="RAM allocated" value={`${(summary.totalMemory / 1024).toFixed(1)} GB`} />
        <SummaryCard icon={Cpu} label="Nodes online" value="1 / 1" />
      </div>

      <div className="flex items-center justify-between">
        <h2 className="text-sm font-medium text-slate-300">Your servers</h2>
        <div className="flex gap-1 rounded-lg border border-white/5 bg-base-800/60 p-1">
          <button
            onClick={() => setView("grid")}
            className={`rounded-md p-1.5 ${view === "grid" ? "bg-accent/20 text-accent-hover" : "text-slate-500 hover:text-slate-300"}`}
          >
            <LayoutGrid size={14} />
          </button>
          <button
            onClick={() => setView("list")}
            className={`rounded-md p-1.5 ${view === "list" ? "bg-accent/20 text-accent-hover" : "text-slate-500 hover:text-slate-300"}`}
          >
            <List size={14} />
          </button>
        </div>
      </div>

      {loading ? (
        <p className="text-sm text-slate-600">Loading servers…</p>
      ) : servers.length === 0 ? (
        <div className="glass rounded-xl p-10 text-center">
          <p className="text-sm text-slate-400">No servers yet. Create your first Minecraft server to get started.</p>
        </div>
      ) : view === "grid" ? (
        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
          {servers.map((s) => (
            <ServerCard key={s.id} server={s} />
          ))}
        </div>
      ) : (
        <div className="glass overflow-hidden rounded-xl">
          <table className="w-full text-left text-sm">
            <thead className="border-b border-white/5 text-xs uppercase text-slate-500">
              <tr>
                <th className="px-4 py-3 font-medium">Name</th>
                <th className="px-4 py-3 font-medium">Status</th>
                <th className="px-4 py-3 font-medium">Image</th>
                <th className="px-4 py-3 font-medium">Memory</th>
                <th className="px-4 py-3 font-medium">Port</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-white/5">
              {servers.map((s) => (
                <tr key={s.id} className="hover:bg-white/[0.02]">
                  <td className="px-4 py-3">
                    <Link to={`/servers/${s.id}/console`} className="font-medium text-slate-100 hover:text-accent-hover">
                      {s.name}
                    </Link>
                  </td>
                  <td className="px-4 py-3"><StatusPill status={s.status} /></td>
                  <td className="px-4 py-3 text-slate-500">{s.image}:{s.dockerImageTag}</td>
                  <td className="px-4 py-3 text-slate-500">{s.memoryLimitMb} MB</td>
                  <td className="px-4 py-3 text-slate-500">{s.primaryPort}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}

function SummaryCard({ icon: Icon, label, value }: { icon: any; label: string; value: string }) {
  return (
    <div className="glass flex items-center gap-4 rounded-xl p-4">
      <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/15 text-accent-hover">
        <Icon size={18} />
      </div>
      <div>
        <p className="text-xs text-slate-500">{label}</p>
        <p className="text-lg font-semibold text-slate-100">{value}</p>
      </div>
    </div>
  );
}

function ServerCard({ server }: { server: GameServer }) {
  return (
    <Link
      to={`/servers/${server.id}/console`}
      className="glass group flex flex-col gap-3 rounded-xl p-4 transition-colors hover:border-white/10"
    >
      <div className="flex items-center justify-between">
        <h3 className="font-medium text-slate-100 group-hover:text-accent-hover">{server.name}</h3>
        <StatusPill status={server.status} />
      </div>
      <p className="text-xs text-slate-500">
        {server.image}:{server.dockerImageTag}
      </p>
      <div className="flex items-center justify-between text-xs text-slate-500">
        <span>{server.memoryLimitMb} MB RAM</span>
        <span>{server.cpuLimitCores} vCPU</span>
        <span>Port {server.primaryPort}</span>
      </div>
    </Link>
  );
}

import { useEffect, useState } from "react";
import { HardDrive, Plus, Wifi, WifiOff, Key } from "lucide-react";
import { api } from "../lib/api";
import Button from "../components/ui/Button";
import Modal from "../components/ui/Modal";
import type { HostNode } from "../types";

export default function Nodes() {
  const [nodes, setNodes] = useState<HostNode[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [tokenModal, setTokenModal] = useState<string | null>(null);
  const [form, setForm] = useState({
    name: "",
    fqdn: "",
    memoryTotalMb: 8192,
    diskTotalMb: 100000,
    cpuCores: 4,
    portRangeStart: 25565,
    portRangeEnd: 25665,
    location: "",
  });

  function load() {
    api.get("/nodes").then((r) => setNodes(r.data.nodes));
  }
  useEffect(load, []);

  async function createNode() {
    const { data } = await api.post("/nodes", form);
    setTokenModal(data.daemonToken);
    setModalOpen(false);
    load();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-slate-100">Host Nodes</h1>
          <p className="mt-1 text-sm text-slate-500">Physical or virtual machines running the Docker daemon.</p>
        </div>
        <Button onClick={() => setModalOpen(true)}>
          <Plus size={16} /> Add node
        </Button>
      </div>

      <div className="grid grid-cols-1 gap-4 sm:grid-cols-2 lg:grid-cols-3">
        {nodes.map((node) => (
          <div key={node.id} className="glass rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center gap-2">
                <HardDrive size={16} className="text-accent-hover" />
                <span className="font-medium text-slate-100">{node.name}</span>
              </div>
              {node.status === "ONLINE" ? (
                <span className="flex items-center gap-1 text-xs text-status-running"><Wifi size={12} /> Online</span>
              ) : (
                <span className="flex items-center gap-1 text-xs text-status-offline"><WifiOff size={12} /> Offline</span>
              )}
            </div>
            <p className="mt-2 text-xs text-slate-500">{node.fqdn}</p>
            <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
              <div className="rounded-md bg-base-800/60 py-2">
                <p className="text-slate-500">RAM</p>
                <p className="font-medium text-slate-200">{(node.memoryTotalMb / 1024).toFixed(0)}GB</p>
              </div>
              <div className="rounded-md bg-base-800/60 py-2">
                <p className="text-slate-500">Disk</p>
                <p className="font-medium text-slate-200">{(node.diskTotalMb / 1024).toFixed(0)}GB</p>
              </div>
              <div className="rounded-md bg-base-800/60 py-2">
                <p className="text-slate-500">CPU</p>
                <p className="font-medium text-slate-200">{node.cpuCores} cores</p>
              </div>
            </div>
            <p className="mt-3 text-xs text-slate-600">
              {node.servers?.length ?? 0} server{(node.servers?.length ?? 0) !== 1 && "s"} hosted
            </p>
          </div>
        ))}
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Register a new node" width="max-w-xl">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Name" value={form.name} onChange={(v) => setForm({ ...form, name: v })} />
          <Field label="FQDN / IP" value={form.fqdn} onChange={(v) => setForm({ ...form, fqdn: v })} />
          <Field label="Memory (MB)" value={String(form.memoryTotalMb)} onChange={(v) => setForm({ ...form, memoryTotalMb: +v })} />
          <Field label="Disk (MB)" value={String(form.diskTotalMb)} onChange={(v) => setForm({ ...form, diskTotalMb: +v })} />
          <Field label="CPU cores" value={String(form.cpuCores)} onChange={(v) => setForm({ ...form, cpuCores: +v })} />
          <Field label="Location" value={form.location} onChange={(v) => setForm({ ...form, location: v })} />
          <Field label="Port range start" value={String(form.portRangeStart)} onChange={(v) => setForm({ ...form, portRangeStart: +v })} />
          <Field label="Port range end" value={String(form.portRangeEnd)} onChange={(v) => setForm({ ...form, portRangeEnd: +v })} />
        </div>
        <div className="mt-4 flex justify-end gap-2">
          <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
          <Button onClick={createNode}>Register node</Button>
        </div>
      </Modal>

      <Modal open={!!tokenModal} onClose={() => setTokenModal(null)} title="Daemon token generated">
        <div className="space-y-3">
          <div className="flex items-center gap-2 text-status-starting">
            <Key size={16} />
            <p className="text-sm">Copy this token now — it won't be shown again.</p>
          </div>
          <code className="block break-all rounded-lg bg-base-950 p-3 text-xs text-accent-hover">{tokenModal}</code>
          <Button className="w-full" onClick={() => setTokenModal(null)}>Done</Button>
        </div>
      </Modal>
    </div>
  );
}

function Field({ label, value, onChange }: { label: string; value: string; onChange: (v: string) => void }) {
  return (
    <div>
      <label className="mb-1 block text-xs text-slate-500">{label}</label>
      <input
        value={value}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-100 outline-none focus:border-accent/50"
      />
    </div>
  );
}

import { useEffect, useState } from "react";
import { UserPlus, Trash2, Shield, ShieldOff } from "lucide-react";
import { api } from "../lib/api";
import Button from "../components/ui/Button";
import Modal from "../components/ui/Modal";

interface PanelUser {
  id: string;
  email: string;
  username: string;
  role: "ADMIN" | "USER";
  isActive: boolean;
  createdAt: string;
}

export default function Users() {
  const [users, setUsers] = useState<PanelUser[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [form, setForm] = useState({ email: "", username: "", password: "", role: "USER" as "ADMIN" | "USER" });

  function load() {
    api.get("/users").then((r) => setUsers(r.data.users));
  }
  useEffect(load, []);

  async function createUser() {
    await api.post("/users", form);
    setModalOpen(false);
    setForm({ email: "", username: "", password: "", role: "USER" });
    load();
  }

  async function toggleActive(u: PanelUser) {
    await api.patch(`/users/${u.id}`, { isActive: !u.isActive });
    load();
  }

  async function removeUser(id: string) {
    if (!confirm("Delete this user? Their servers will remain but become unowned.")) return;
    await api.delete(`/users/${id}`);
    load();
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-xl font-semibold text-slate-100">User Access</h1>
          <p className="mt-1 text-sm text-slate-500">Manage panel accounts and their global role.</p>
        </div>
        <Button onClick={() => setModalOpen(true)}>
          <UserPlus size={16} /> Add user
        </Button>
      </div>

      <div className="glass overflow-hidden rounded-xl">
        <table className="w-full text-left text-sm">
          <thead className="border-b border-white/5 text-xs uppercase text-slate-500">
            <tr>
              <th className="px-4 py-3 font-medium">User</th>
              <th className="px-4 py-3 font-medium">Role</th>
              <th className="px-4 py-3 font-medium">Status</th>
              <th className="px-4 py-3 font-medium">Joined</th>
              <th className="px-4 py-3"></th>
            </tr>
          </thead>
          <tbody className="divide-y divide-white/5">
            {users.map((u) => (
              <tr key={u.id} className="hover:bg-white/[0.02]">
                <td className="px-4 py-3">
                  <p className="font-medium text-slate-100">{u.username}</p>
                  <p className="text-xs text-slate-500">{u.email}</p>
                </td>
                <td className="px-4 py-3">
                  <span className={`rounded-full px-2 py-0.5 text-xs ${u.role === "ADMIN" ? "bg-accent/15 text-accent-hover" : "bg-base-750 text-slate-400"}`}>
                    {u.role}
                  </span>
                </td>
                <td className="px-4 py-3">
                  <span className={u.isActive ? "text-status-running text-xs" : "text-status-offline text-xs"}>
                    {u.isActive ? "Active" : "Disabled"}
                  </span>
                </td>
                <td className="px-4 py-3 text-xs text-slate-500">{new Date(u.createdAt).toLocaleDateString()}</td>
                <td className="px-4 py-3">
                  <div className="flex justify-end gap-1">
                    <button onClick={() => toggleActive(u)} className="rounded-md p-2 text-slate-500 hover:bg-white/5 hover:text-slate-200">
                      {u.isActive ? <ShieldOff size={14} /> : <Shield size={14} />}
                    </button>
                    <button onClick={() => removeUser(u.id)} className="rounded-md p-2 text-slate-500 hover:bg-white/5 hover:text-red-400">
                      <Trash2 size={14} />
                    </button>
                  </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Add user">
        <div className="space-y-3">
          <input placeholder="Email" value={form.email} onChange={(e) => setForm({ ...form, email: e.target.value })}
            className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-100 outline-none focus:border-accent/50" />
          <input placeholder="Username" value={form.username} onChange={(e) => setForm({ ...form, username: e.target.value })}
            className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-100 outline-none focus:border-accent/50" />
          <input placeholder="Password" type="password" value={form.password} onChange={(e) => setForm({ ...form, password: e.target.value })}
            className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-100 outline-none focus:border-accent/50" />
          <select value={form.role} onChange={(e) => setForm({ ...form, role: e.target.value as "ADMIN" | "USER" })}
            className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-200">
            <option value="USER">User</option>
            <option value="ADMIN">Admin</option>
          </select>
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button onClick={createUser}>Create</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

import { useEffect, useRef, useState } from "react";
import { useParams } from "react-router-dom";
import { Terminal } from "@xterm/xterm";
import { FitAddon } from "@xterm/addon-fit";
import "@xterm/xterm/css/xterm.css";
import { Play, Square, RotateCw, Zap, Download, Send } from "lucide-react";
import { useServerSocket } from "../../hooks/useServerSocket";
import Button from "../../components/ui/Button";
import StatusPill from "../../components/ui/StatusPill";
import type { ContainerStats, ServerStatus } from "../../types";

const TERMINAL_THEME = {
  background: "#0a0b0f",
  foreground: "#cbd5e1",
  cursor: "#6366f1",
  black: "#151822",
  brightBlack: "#3a4152",
  red: "#ef4444",
  green: "#22c55e",
  yellow: "#eab308",
  blue: "#6366f1",
  magenta: "#a855f7",
  cyan: "#06b6d4",
  white: "#e2e8f0",
};

export default function ServerConsole() {
  const { id: serverId } = useParams<{ id: string }>();
  const containerRef = useRef<HTMLDivElement>(null);
  const termRef = useRef<Terminal | null>(null);
  const fitRef = useRef<FitAddon | null>(null);
  const logBufferRef = useRef<string[]>([]);
  const inputRef = useRef<HTMLInputElement>(null);

  const [status, setStatus] = useState<ServerStatus>("OFFLINE");
  const [stats, setStats] = useState<ContainerStats | null>(null);
  const [command, setCommand] = useState("");

  const { connected, sendCommand, sendPowerAction } = useServerSocket({
    serverId: serverId!,
    onConsoleLine: (line) => {
      logBufferRef.current.push(line);
      termRef.current?.write(line.replace(/\n/g, "\r\n"));
    },
    onStats: setStats,
    onStatus: setStatus,
  });

  useEffect(() => {
    if (!containerRef.current) return;
    const term = new Terminal({
      convertEol: true,
      fontFamily: "'JetBrains Mono', monospace",
      fontSize: 13,
      theme: TERMINAL_THEME,
      cursorBlink: true,
      disableStdin: true,
      scrollback: 5000,
    });
    const fit = new FitAddon();
    term.loadAddon(fit);
    term.open(containerRef.current);
    fit.fit();
    term.writeln("\x1b[90mConnecting to server console...\x1b[0m");

    termRef.current = term;
    fitRef.current = fit;

    const onResize = () => fit.fit();
    window.addEventListener("resize", onResize);
    return () => {
      window.removeEventListener("resize", onResize);
      term.dispose();
    };
  }, []);

  function submitCommand(e: React.FormEvent) {
    e.preventDefault();
    if (!command.trim()) return;
    termRef.current?.writeln(`\x1b[36m> ${command}\x1b[0m`);
    sendCommand(command);
    setCommand("");
  }

  function downloadLogs() {
    const blob = new Blob([logBufferRef.current.join("")], { type: "text/plain" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `server-${serverId}-console.log`;
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <div className="flex h-full flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-3">
          <StatusPill status={status} />
          <span className={`text-xs ${connected ? "text-status-running" : "text-slate-600"}`}>
            {connected ? "● Live" : "○ Connecting…"}
          </span>
        </div>
        <div className="flex items-center gap-2">
          <Button size="sm" variant="secondary" onClick={() => sendPowerAction("start")}>
            <Play size={14} /> Start
          </Button>
          <Button size="sm" variant="secondary" onClick={() => sendPowerAction("restart")}>
            <RotateCw size={14} /> Restart
          </Button>
          <Button size="sm" variant="secondary" onClick={() => sendPowerAction("stop")}>
            <Square size={14} /> Stop
          </Button>
          <Button size="sm" variant="danger" onClick={() => sendPowerAction("kill")}>
            <Zap size={14} /> Kill
          </Button>
          <Button size="sm" variant="ghost" onClick={downloadLogs}>
            <Download size={14} /> Logs
          </Button>
        </div>
      </div>

      {stats && (
        <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
          <StatBox label="CPU" value={`${stats.cpuPercent.toFixed(1)}%`} />
          <StatBox label="Memory" value={`${stats.memoryUsedMb} / ${stats.memoryLimitMb} MB`} />
          <StatBox label="Network" value={`↓${formatBytes(stats.networkRxBytes)} ↑${formatBytes(stats.networkTxBytes)}`} />
          <StatBox label="Uptime" value={formatUptime(stats.uptimeSeconds)} />
        </div>
      )}

      <div className="glass min-h-0 flex-1 rounded-xl p-3">
        <div ref={containerRef} className="h-full w-full" />
      </div>

      <form onSubmit={submitCommand} className="flex items-center gap-2">
        <input
          ref={inputRef}
          value={command}
          onChange={(e) => setCommand(e.target.value)}
          placeholder="Type a command and press Enter…"
          className="flex-1 rounded-lg border border-white/5 bg-base-800/80 px-4 py-2.5 text-sm font-mono text-slate-100 outline-none placeholder:text-slate-600 focus:border-accent/50"
        />
        <Button type="submit" size="md">
          <Send size={14} /> Send
        </Button>
      </form>
    </div>
  );
}

function StatBox({ label, value }: { label: string; value: string }) {
  return (
    <div className="glass rounded-lg px-3 py-2">
      <p className="text-[11px] text-slate-500">{label}</p>
      <p className="text-sm font-semibold text-slate-100">{value}</p>
    </div>
  );
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return `${bytes}B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)}KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)}MB`;
}

function formatUptime(seconds: number): string {
  const h = Math.floor(seconds / 3600);
  const m = Math.floor((seconds % 3600) / 60);
  return `${h}h ${m}m`;
}

import { useCallback, useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import {
  Folder,
  File as FileIcon,
  ChevronRight,
  Upload,
  FolderPlus,
  Trash2,
  Save,
  ArrowLeft,
  Download as DownloadIcon,
} from "lucide-react";
import { api } from "../../lib/api";
import Button from "../../components/ui/Button";
import Modal from "../../components/ui/Modal";
import type { FileNode } from "../../types";

export default function FileManager() {
  const { id: serverId } = useParams<{ id: string }>();
  const [path, setPath] = useState("/");
  const [files, setFiles] = useState<FileNode[]>([]);
  const [loading, setLoading] = useState(true);
  const [editing, setEditing] = useState<FileNode | null>(null);
  const [content, setContent] = useState("");
  const [dragOver, setDragOver] = useState(false);
  const [newFolderOpen, setNewFolderOpen] = useState(false);
  const [newFolderName, setNewFolderName] = useState("");

  const load = useCallback(
    (p: string) => {
      setLoading(true);
      api
        .get(`/servers/${serverId}/files`, { params: { path: p } })
        .then((r) => setFiles(r.data.files))
        .finally(() => setLoading(false));
    },
    [serverId]
  );

  useEffect(() => load(path), [path, load]);

  function openFile(node: FileNode) {
    if (node.type === "directory") {
      setPath(node.path);
      return;
    }
    api.get(`/servers/${serverId}/files/content`, { params: { path: node.path } }).then((r) => {
      setEditing(node);
      setContent(r.data.content);
    });
  }

  async function saveFile() {
    if (!editing) return;
    await api.put(`/servers/${serverId}/files/content`, { path: editing.path, content });
    setEditing(null);
  }

  async function deleteFile(node: FileNode, e: React.MouseEvent) {
    e.stopPropagation();
    if (!confirm(`Delete ${node.name}? This cannot be undone.`)) return;
    await api.delete(`/servers/${serverId}/files`, { params: { path: node.path } });
    load(path);
  }

  async function createFolder() {
    if (!newFolderName.trim()) return;
    await api.post(`/servers/${serverId}/files/mkdir`, { path: `${path}/${newFolderName}`.replace(/\/+/g, "/") });
    setNewFolderName("");
    setNewFolderOpen(false);
    load(path);
  }

  async function handleDrop(e: React.DragEvent) {
    e.preventDefault();
    setDragOver(false);
    const droppedFiles = Array.from(e.dataTransfer.files);
    for (const file of droppedFiles) {
      const form = new FormData();
      form.append("file", file);
      await api.post(`/servers/${serverId}/files/upload`, form, {
        params: { path },
        headers: { "Content-Type": "multipart/form-data" },
      });
    }
    load(path);
  }

  const crumbs = path.split("/").filter(Boolean);

  return (
    <div className="flex h-full flex-col gap-4">
      <div className="flex flex-wrap items-center justify-between gap-3">
        <div className="flex items-center gap-1 text-sm text-slate-400">
          <button onClick={() => setPath("/")} className="hover:text-slate-200">root</button>
          {crumbs.map((c, i) => (
            <span key={i} className="flex items-center gap-1">
              <ChevronRight size={12} className="text-slate-600" />
              <button onClick={() => setPath("/" + crumbs.slice(0, i + 1).join("/"))} className="hover:text-slate-200">
                {c}
              </button>
            </span>
          ))}
        </div>
        <div className="flex gap-2">
          <Button size="sm" variant="secondary" onClick={() => setNewFolderOpen(true)}>
            <FolderPlus size={14} /> New folder
          </Button>
          <label className="cursor-pointer">
            <input
              type="file"
              multiple
              className="hidden"
              onChange={async (e) => {
                for (const file of Array.from(e.target.files ?? [])) {
                  const form = new FormData();
                  form.append("file", file);
                  await api.post(`/servers/${serverId}/files/upload`, form, { params: { path } });
                }
                load(path);
              }}
            />
            <span className="inline-flex items-center gap-2 rounded-lg bg-accent px-4 py-2 text-sm font-medium text-white hover:bg-accent-hover">
              <Upload size={14} /> Upload
            </span>
          </label>
        </div>
      </div>

      <div
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver(true);
        }}
        onDragLeave={() => setDragOver(false)}
        onDrop={handleDrop}
        className={`glass flex-1 overflow-y-auto rounded-xl p-2 transition-colors ${dragOver ? "ring-2 ring-accent/60" : ""}`}
      >
        {dragOver && (
          <div className="flex h-full items-center justify-center text-sm text-accent-hover">Drop files to upload</div>
        )}
        {!dragOver && loading && <p className="p-4 text-sm text-slate-600">Loading…</p>}
        {!dragOver && !loading && files.length === 0 && (
          <p className="p-4 text-sm text-slate-600">This directory is empty.</p>
        )}
        {!dragOver &&
          !loading &&
          files.map((node) => (
            <div
              key={node.path}
              onClick={() => openFile(node)}
              className="group flex cursor-pointer items-center justify-between rounded-lg px-3 py-2 text-sm hover:bg-white/5"
            >
              <div className="flex items-center gap-3">
                {node.type === "directory" ? (
                  <Folder size={16} className="text-accent-hover" />
                ) : (
                  <FileIcon size={16} className="text-slate-500" />
                )}
                <span className="text-slate-200">{node.name}</span>
              </div>
              <div className="flex items-center gap-4">
                <span className="text-xs text-slate-600">{node.type === "file" ? formatSize(node.size) : ""}</span>
                <button
                  onClick={(e) => deleteFile(node, e)}
                  className="opacity-0 group-hover:opacity-100 text-slate-500 hover:text-red-400"
                >
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
      </div>

      {/* Full-screen text editor */}
      <Modal open={!!editing} onClose={() => setEditing(null)} title={editing?.name ?? ""} width="max-w-4xl">
        <div className="space-y-3">
          <textarea
            value={content}
            onChange={(e) => setContent(e.target.value)}
            spellCheck={false}
            className="h-[60vh] w-full resize-none rounded-lg border border-white/5 bg-base-950 p-4 font-mono text-sm text-slate-200 outline-none focus:border-accent/50"
          />
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setEditing(null)}>
              <ArrowLeft size={14} /> Cancel
            </Button>
            <Button onClick={saveFile}>
              <Save size={14} /> Save changes
            </Button>
          </div>
        </div>
      </Modal>

      <Modal open={newFolderOpen} onClose={() => setNewFolderOpen(false)} title="New folder">
        <div className="space-y-3">
          <input
            autoFocus
            value={newFolderName}
            onChange={(e) => setNewFolderName(e.target.value)}
            placeholder="folder-name"
            className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-100 outline-none focus:border-accent/50"
          />
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setNewFolderOpen(false)}>Cancel</Button>
            <Button onClick={createFolder}>Create</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

function formatSize(bytes: number): string {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 ** 2) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / 1024 ** 2).toFixed(1)} MB`;
}

import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Search, Download, Loader2 } from "lucide-react";
import { api } from "../../lib/api";
import Button from "../../components/ui/Button";
import type { ModrinthProject } from "../../types";

const LOADERS = ["fabric", "forge", "paper", "spigot", "quilt"];

export default function PluginStore() {
  const { id: serverId } = useParams<{ id: string }>();
  const [query, setQuery] = useState("");
  const [loader, setLoader] = useState("paper");
  const [gameVersion, setGameVersion] = useState("1.21.1");
  const [results, setResults] = useState<ModrinthProject[]>([]);
  const [loading, setLoading] = useState(false);
  const [installing, setInstalling] = useState<string | null>(null);
  const [versionPickerFor, setVersionPickerFor] = useState<ModrinthProject | null>(null);
  const [versions, setVersions] = useState<any[]>([]);

  async function search() {
    setLoading(true);
    try {
      const { data } = await api.get("/modrinth/search", { params: { q: query, loader, gameVersion } });
      setResults(data.hits ?? []);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    search();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function openVersionPicker(project: ModrinthProject) {
    setVersionPickerFor(project);
    const { data } = await api.get(`/modrinth/project/${project.project_id}/versions`, { params: { loader, gameVersion } });
    setVersions(data);
  }

  async function install(versionId: string) {
    if (!versionPickerFor) return;
    setInstalling(versionPickerFor.project_id);
    try {
      await api.post(`/servers/${serverId}/modrinth/install`, { versionId, targetDir: "/plugins" });
      setVersionPickerFor(null);
    } finally {
      setInstalling(null);
    }
  }

  return (
    <div className="space-y-4">
      <div className="flex flex-wrap items-center gap-2">
        <div className="relative flex-1 min-w-[200px]">
          <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-500" />
          <input
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && search()}
            placeholder="Search Modrinth plugins & mods…"
            className="w-full rounded-lg border border-white/5 bg-base-800 py-2 pl-9 pr-3 text-sm text-slate-100 outline-none focus:border-accent/50"
          />
        </div>
        <select
          value={loader}
          onChange={(e) => setLoader(e.target.value)}
          className="rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-200"
        >
          {LOADERS.map((l) => (
            <option key={l} value={l}>{l}</option>
          ))}
        </select>
        <input
          value={gameVersion}
          onChange={(e) => setGameVersion(e.target.value)}
          className="w-24 rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-200"
          placeholder="1.21.1"
        />
        <Button onClick={search}>Search</Button>
      </div>

      {loading ? (
        <div className="flex justify-center py-10"><Loader2 className="animate-spin text-slate-600" /></div>
      ) : (
        <div className="grid grid-cols-1 gap-3 sm:grid-cols-2">
          {results.map((project) => (
            <div key={project.project_id} className="glass flex gap-3 rounded-xl p-4">
              {project.icon_url ? (
                <img src={project.icon_url} alt="" className="h-12 w-12 rounded-lg object-cover" />
              ) : (
                <div className="h-12 w-12 shrink-0 rounded-lg bg-base-750" />
              )}
              <div className="min-w-0 flex-1">
                <p className="truncate text-sm font-medium text-slate-100">{project.title}</p>
                <p className="mt-0.5 line-clamp-2 text-xs text-slate-500">{project.description}</p>
                <div className="mt-2 flex items-center justify-between">
                  <span className="text-[11px] text-slate-600">{project.downloads?.toLocaleString()} downloads</span>
                  <Button size="sm" variant="secondary" onClick={() => openVersionPicker(project)}>
                    <Download size={12} /> Install
                  </Button>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {versionPickerFor && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 p-4" onClick={() => setVersionPickerFor(null)}>
          <div className="glass w-full max-w-md rounded-xl p-5" onClick={(e) => e.stopPropagation()}>
            <h3 className="mb-3 text-sm font-semibold text-slate-100">Select a version — {versionPickerFor.title}</h3>
            <div className="max-h-64 space-y-1 overflow-y-auto">
              {versions.length === 0 && <p className="text-sm text-slate-600">No compatible versions found.</p>}
              {versions.map((v: any) => (
                <button
                  key={v.id}
                  onClick={() => install(v.id)}
                  disabled={installing === versionPickerFor.project_id}
                  className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm hover:bg-white/5"
                >
                  <span className="text-slate-200">{v.name || v.version_number}</span>
                  <span className="text-xs text-slate-600">{v.game_versions?.[0]}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

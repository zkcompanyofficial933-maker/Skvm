import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Globe, Archive, RotateCcw, Trash2, Plus } from "lucide-react";
import { api } from "../../lib/api";
import Button from "../../components/ui/Button";
import Modal from "../../components/ui/Modal";

interface BackupRecord {
  id: string;
  name: string;
  sizeBytes: number;
  isSuccessful: boolean;
  createdAt: string;
}

export default function WorldManager() {
  const { id: serverId } = useParams<{ id: string }>();
  const [backups, setBackups] = useState<BackupRecord[]>([]);
  const [creating, setCreating] = useState(false);
  const [backupName, setBackupName] = useState("");
  const [worlds] = useState(["world", "world_nether", "world_the_end"]);
  const [activeWorld, setActiveWorld] = useState("world");

  function loadBackups() {
    api.get(`/servers/${serverId}`).then((r) => setBackups(r.data.server.backups ?? []));
  }
  useEffect(loadBackups, [serverId]);

  async function createBackup() {
    await api.post(`/servers/${serverId}/files/compress`, {
      path: `/${activeWorld}`,
      archiveName: `backups/${backupName || activeWorld}-${Date.now()}.tar.gz`,
    });
    setCreating(false);
    setBackupName("");
    loadBackups();
  }

  async function restoreBackup(name: string) {
    if (!confirm(`Restore "${name}"? This will overwrite the current world.`)) return;
    await api.post(`/servers/${serverId}/files/extract`, { archivePath: `/backups/${name}`, destPath: "/" });
  }

  return (
    <div className="space-y-6">
      <div>
        <h2 className="mb-3 text-sm font-medium text-slate-300">World switcher</h2>
        <div className="flex flex-wrap gap-2">
          {worlds.map((w) => (
            <button
              key={w}
              onClick={() => setActiveWorld(w)}
              className={`flex items-center gap-2 rounded-lg border px-4 py-2.5 text-sm transition-colors ${
                activeWorld === w
                  ? "border-accent/40 bg-accent/10 text-accent-hover"
                  : "border-white/5 bg-base-800/60 text-slate-400 hover:text-slate-200"
              }`}
            >
              <Globe size={14} /> {w}
            </button>
          ))}
        </div>
      </div>

      <div className="flex items-center justify-between">
        <h2 className="text-sm font-medium text-slate-300">Backups — {activeWorld}</h2>
        <Button size="sm" onClick={() => setCreating(true)}>
          <Plus size={14} /> Create backup
        </Button>
      </div>

      {backups.length === 0 ? (
        <div className="glass rounded-xl p-8 text-center text-sm text-slate-500">
          No backups yet. Create one before installing new plugins or updating the world.
        </div>
      ) : (
        <div className="glass divide-y divide-white/5 overflow-hidden rounded-xl">
          {backups.map((b) => (
            <div key={b.id} className="flex items-center justify-between px-4 py-3">
              <div className="flex items-center gap-3">
                <Archive size={16} className="text-accent-hover" />
                <div>
                  <p className="text-sm font-medium text-slate-100">{b.name}</p>
                  <p className="text-xs text-slate-500">
                    {(b.sizeBytes / 1024 / 1024).toFixed(1)} MB · {new Date(b.createdAt).toLocaleString()}
                  </p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                <button onClick={() => restoreBackup(b.name)} className="rounded-md p-2 text-slate-500 hover:bg-white/5 hover:text-slate-200">
                  <RotateCcw size={14} />
                </button>
                <button className="rounded-md p-2 text-slate-500 hover:bg-white/5 hover:text-red-400">
                  <Trash2 size={14} />
                </button>
              </div>
            </div>
          ))}
        </div>
      )}

      <Modal open={creating} onClose={() => setCreating(false)} title="Create backup">
        <div className="space-y-3">
          <input
            autoFocus
            value={backupName}
            onChange={(e) => setBackupName(e.target.value)}
            placeholder={`${activeWorld}-backup`}
            className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-100 outline-none focus:border-accent/50"
          />
          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setCreating(false)}>Cancel</Button>
            <Button onClick={createBackup}>Create</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

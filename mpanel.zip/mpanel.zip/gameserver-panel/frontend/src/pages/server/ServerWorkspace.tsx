import { NavLink, Outlet, useParams } from "react-router-dom";
import { useEffect, useState } from "react";
import clsx from "clsx";
import { Terminal, FolderOpen, Users, Package, Globe2, Radio, ShieldCheck } from "lucide-react";
import { api } from "../../lib/api";
import StatusPill from "../../components/ui/StatusPill";
import type { GameServer } from "../../types";

const TABS = [
  { to: "console", label: "Console", icon: Terminal },
  { to: "files", label: "Files", icon: FolderOpen },
  { to: "players", label: "Players", icon: Users },
  { to: "plugins", label: "Plugins & Mods", icon: Package },
  { to: "world", label: "World", icon: Globe2 },
  { to: "tunnel", label: "Tunneling", icon: Radio },
  { to: "access", label: "Sub-Users", icon: ShieldCheck },
];

export default function ServerWorkspace() {
  const { id } = useParams<{ id: string }>();
  const [server, setServer] = useState<GameServer | null>(null);

  useEffect(() => {
    api.get(`/servers/${id}`).then((r) => setServer(r.data.server));
  }, [id]);

  return (
    <div className="flex h-full flex-col gap-4">
      <div className="flex items-center justify-between">
        <div>
          <div className="flex items-center gap-3">
            <h1 className="text-xl font-semibold text-slate-100">{server?.name ?? "Loading…"}</h1>
            {server && <StatusPill status={server.status} />}
          </div>
          {server && (
            <p className="mt-1 text-xs text-slate-500">
              {server.image}:{server.dockerImageTag} · {server.memoryLimitMb} MB RAM · {server.cpuLimitCores} vCPU
            </p>
          )}
        </div>
      </div>

      <div className="flex gap-1 overflow-x-auto border-b border-white/5">
        {TABS.map((tab) => (
          <NavLink
            key={tab.to}
            to={tab.to}
            className={({ isActive }) =>
              clsx(
                "flex shrink-0 items-center gap-2 border-b-2 px-4 py-2.5 text-sm font-medium transition-colors",
                isActive ? "border-accent text-slate-100" : "border-transparent text-slate-500 hover:text-slate-300"
              )
            }
          >
            <tab.icon size={15} /> {tab.label}
          </NavLink>
        ))}
      </div>

      <div className="min-h-0 flex-1">
        <Outlet />
      </div>
    </div>
  );
}

import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { Radio, Copy, Check, Plus, Power } from "lucide-react";
import { api } from "../../lib/api";
import Button from "../../components/ui/Button";
import type { Tunnel } from "../../types";

export default function Tunneling() {
  const { id: serverId } = useParams<{ id: string }>();
  const [tunnels, setTunnels] = useState<Tunnel[]>([]);
  const [copied, setCopied] = useState(false);

  function load() {
    api.get(`/servers/${serverId}`).then((r) => setTunnels(r.data.server.tunnels ?? []));
  }
  useEffect(load, [serverId]);

  function copy(address: string) {
    navigator.clipboard.writeText(address);
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  }

  const active = tunnels.find((t) => t.status === "active");

  return (
    <div className="space-y-6">
      <div className="glass rounded-xl p-6">
        <div className="flex items-center gap-3">
          <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-accent/15 text-accent-hover">
            <Radio size={18} />
          </div>
          <div>
            <h2 className="text-sm font-semibold text-slate-100">playit.gg tunnel</h2>
            <p className="text-xs text-slate-500">Get a public address without forwarding ports on your router.</p>
          </div>
        </div>

        {active ? (
          <div className="mt-5 flex items-center justify-between rounded-lg border border-white/5 bg-base-800/60 px-4 py-3">
            <div>
              <p className="text-[11px] text-slate-500">Public address</p>
              <p className="font-mono text-sm text-slate-100">{active.publicAddress}</p>
            </div>
            <button
              onClick={() => copy(active.publicAddress ?? "")}
              className="flex items-center gap-1.5 rounded-md bg-white/5 px-3 py-1.5 text-xs text-slate-300 hover:bg-white/10"
            >
              {copied ? <Check size={12} /> : <Copy size={12} />}
              {copied ? "Copied" : "Copy"}
            </button>
          </div>
        ) : (
          <div className="mt-5 flex items-center justify-between rounded-lg border border-dashed border-white/10 px-4 py-6">
            <p className="text-sm text-slate-500">No active tunnel for this server.</p>
            <Button size="sm">
              <Plus size={14} /> Create tunnel
            </Button>
          </div>
        )}
      </div>

      {tunnels.length > 0 && (
        <div>
          <h3 className="mb-2 text-sm font-medium text-slate-300">Tunnel history</h3>
          <div className="glass divide-y divide-white/5 overflow-hidden rounded-xl">
            {tunnels.map((t) => (
              <div key={t.id} className="flex items-center justify-between px-4 py-3">
                <div>
                  <p className="font-mono text-sm text-slate-200">{t.publicAddress ?? "—"}</p>
                  <p className="text-xs text-slate-500">Local port {t.localPort} · {t.provider}</p>
                </div>
                <span
                  className={`rounded-full px-2.5 py-1 text-xs ${
                    t.status === "active"
                      ? "bg-status-running/10 text-status-running"
                      : t.status === "error"
                      ? "bg-status-error/10 text-status-error"
                      : "bg-status-offline/10 text-status-offline"
                  }`}
                >
                  {t.status}
                </span>
                <button className="rounded-md p-2 text-slate-500 hover:bg-white/5 hover:text-red-400">
                  <Power size={14} />
                </button>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

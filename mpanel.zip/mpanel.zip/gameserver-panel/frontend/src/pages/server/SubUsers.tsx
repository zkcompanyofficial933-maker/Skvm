import { useEffect, useState } from "react";
import { useParams } from "react-router-dom";
import { UserPlus, Trash2, Shield } from "lucide-react";
import { api } from "../../lib/api";
import Button from "../../components/ui/Button";
import Modal from "../../components/ui/Modal";
import { PERMISSION_GROUPS } from "../../types";
import type { SubUser, Permission } from "../../types";

export default function SubUsers() {
  const { id: serverId } = useParams<{ id: string }>();
  const [subUsers, setSubUsers] = useState<SubUser[]>([]);
  const [modalOpen, setModalOpen] = useState(false);
  const [email, setEmail] = useState("");
  const [selectedPerms, setSelectedPerms] = useState<Set<Permission>>(new Set());

  function load() {
    api.get(`/servers/${serverId}/sub-users`).then((r) => setSubUsers(r.data.subUsers));
  }
  useEffect(load, [serverId]);

  function togglePerm(p: Permission) {
    setSelectedPerms((prev) => {
      const next = new Set(prev);
      next.has(p) ? next.delete(p) : next.add(p);
      return next;
    });
  }

  async function addSubUser() {
    // In a full implementation this resolves email -> userId via a users lookup endpoint.
    // Here we assume the identifier field IS the userId for simplicity of the panel's UI contract.
    await api.put(`/servers/${serverId}/sub-users`, { userId: email, permissions: [...selectedPerms] });
    setModalOpen(false);
    setEmail("");
    setSelectedPerms(new Set());
    load();
  }

  async function removeSubUser(userId: string) {
    if (!confirm("Remove this sub-user's access?")) return;
    await api.delete(`/servers/${serverId}/sub-users/${userId}`);
    load();
  }

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-sm font-medium text-slate-300">Sub-user access</h2>
          <p className="mt-1 text-xs text-slate-500">Grant scoped, granular access to this server without full ownership.</p>
        </div>
        <Button size="sm" onClick={() => setModalOpen(true)}>
          <UserPlus size={14} /> Add sub-user
        </Button>
      </div>

      {subUsers.length === 0 ? (
        <div className="glass rounded-xl p-8 text-center text-sm text-slate-500">No sub-users have access to this server yet.</div>
      ) : (
        <div className="glass divide-y divide-white/5 overflow-hidden rounded-xl">
          {subUsers.map((su) => (
            <div key={su.id} className="flex items-center justify-between px-4 py-3">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-accent/15 text-accent-hover">
                  <Shield size={14} />
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-100">{su.user?.username ?? su.userId}</p>
                  <p className="text-xs text-slate-500">{su.permissions.length} permissions granted</p>
                </div>
              </div>
              <button onClick={() => removeSubUser(su.userId)} className="rounded-md p-2 text-slate-500 hover:bg-white/5 hover:text-red-400">
                <Trash2 size={14} />
              </button>
            </div>
          ))}
        </div>
      )}

      <Modal open={modalOpen} onClose={() => setModalOpen(false)} title="Add sub-user" width="max-w-xl">
        <div className="space-y-4">
          <div>
            <label className="mb-1 block text-xs text-slate-500">User ID or email</label>
            <input
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              placeholder="user-id"
              className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2 text-sm text-slate-100 outline-none focus:border-accent/50"
            />
          </div>

          <div>
            <label className="mb-2 block text-xs text-slate-500">Permission matrix</label>
            <div className="max-h-72 space-y-4 overflow-y-auto rounded-lg border border-white/5 p-3">
              {Object.entries(PERMISSION_GROUPS).map(([group, perms]) => (
                <div key={group}>
                  <p className="mb-1.5 text-xs font-medium text-slate-400">{group}</p>
                  <div className="grid grid-cols-2 gap-2">
                    {perms.map((p) => (
                      <label key={p} className="flex items-center gap-2 rounded-md px-2 py-1.5 text-sm text-slate-300 hover:bg-white/5">
                        <input
                          type="checkbox"
                          checked={selectedPerms.has(p)}
                          onChange={() => togglePerm(p)}
                          className="rounded border-white/20 bg-base-800 text-accent focus:ring-accent"
                        />
                        {p}
                      </label>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div className="flex justify-end gap-2">
            <Button variant="secondary" onClick={() => setModalOpen(false)}>Cancel</Button>
            <Button onClick={addSubUser}>Grant access</Button>
          </div>
        </div>
      </Modal>
    </div>
  );
}

import { useState } from "react";
import { useParams } from "react-router-dom";
import { UserX, Ban, ShieldCheck, MessageSquare } from "lucide-react";
import { useServerSocket } from "../../hooks/useServerSocket";
import Button from "../../components/ui/Button";
import type { Player } from "../../types";

// Players are derived from parsed console output (e.g. Minecraft's "Player X joined the game").
// A production daemon would maintain this list server-side by tailing the log; here the
// panel listens on the same console stream and updates the roster in real time.
export default function PlayerManager() {
  const { id: serverId } = useParams<{ id: string }>();
  const [players, setPlayers] = useState<Player[]>([]);
  const [messageTarget, setMessageTarget] = useState<Player | null>(null);
  const [messageText, setMessageText] = useState("");

  const { sendCommand } = useServerSocket({
    serverId: serverId!,
    onConsoleLine: (line) => {
      const joinMatch = line.match(/(\w+) joined the game/);
      const leaveMatch = line.match(/(\w+) left the game/);
      if (joinMatch) {
        setPlayers((prev) =>
          prev.some((p) => p.name === joinMatch[1])
            ? prev.map((p) => (p.name === joinMatch[1] ? { ...p, online: true } : p))
            : [...prev, { name: joinMatch[1], uuid: joinMatch[1], online: true, isOp: false }]
        );
      }
      if (leaveMatch) {
        setPlayers((prev) => prev.map((p) => (p.name === leaveMatch[1] ? { ...p, online: false } : p)));
      }
    },
  });

  function kick(player: Player) {
    sendCommand(`kick ${player.name}`);
  }
  function ban(player: Player) {
    if (!confirm(`Ban ${player.name}?`)) return;
    sendCommand(`ban ${player.name}`);
  }
  function toggleOp(player: Player) {
    sendCommand(`${player.isOp ? "deop" : "op"} ${player.name}`);
    setPlayers((prev) => prev.map((p) => (p.name === player.name ? { ...p, isOp: !p.isOp } : p)));
  }
  function sendMessage() {
    if (!messageTarget || !messageText.trim()) return;
    sendCommand(`tell ${messageTarget.name} ${messageText}`);
    setMessageTarget(null);
    setMessageText("");
  }

  const online = players.filter((p) => p.online);

  return (
    <div className="space-y-4">
      <div>
        <h2 className="text-sm font-medium text-slate-300">Online players ({online.length})</h2>
        <p className="mt-1 text-xs text-slate-500">
          Roster updates live from console activity — start the server and have players join to populate this list.
        </p>
      </div>

      {online.length === 0 ? (
        <div className="glass rounded-xl p-8 text-center text-sm text-slate-500">No players currently online.</div>
      ) : (
        <div className="glass divide-y divide-white/5 overflow-hidden rounded-xl">
          {online.map((player) => (
            <div key={player.name} className="flex items-center justify-between px-4 py-3">
              <div className="flex items-center gap-3">
                <div className="flex h-8 w-8 items-center justify-center rounded-md bg-accent/15 text-xs font-semibold text-accent-hover">
                  {player.name.slice(0, 2).toUpperCase()}
                </div>
                <div>
                  <p className="text-sm font-medium text-slate-100">{player.name}</p>
                  {player.isOp && <p className="text-[11px] text-status-starting">Operator</p>}
                </div>
              </div>
              <div className="flex items-center gap-1.5">
                <IconButton title="Message" onClick={() => setMessageTarget(player)}>
                  <MessageSquare size={14} />
                </IconButton>
                <IconButton title={player.isOp ? "Revoke OP" : "Grant OP"} onClick={() => toggleOp(player)}>
                  <ShieldCheck size={14} className={player.isOp ? "text-status-starting" : ""} />
                </IconButton>
                <IconButton title="Kick" onClick={() => kick(player)}>
                  <UserX size={14} />
                </IconButton>
                <IconButton title="Ban" danger onClick={() => ban(player)}>
                  <Ban size={14} />
                </IconButton>
              </div>
            </div>
          ))}
        </div>
      )}

      {messageTarget && (
        <div className="glass flex items-center gap-2 rounded-xl p-3">
          <span className="text-xs text-slate-500">To {messageTarget.name}:</span>
          <input
            autoFocus
            value={messageText}
            onChange={(e) => setMessageText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && sendMessage()}
            className="flex-1 rounded-md border border-white/5 bg-base-800 px-3 py-1.5 text-sm text-slate-100 outline-none focus:border-accent/50"
            placeholder="Type a whisper…"
          />
          <Button size="sm" onClick={sendMessage}>Send</Button>
          <Button size="sm" variant="ghost" onClick={() => setMessageTarget(null)}>Cancel</Button>
        </div>
      )}
    </div>
  );
}

function IconButton({
  children,
  onClick,
  title,
  danger,
}: {
  children: React.ReactNode;
  onClick: () => void;
  title: string;
  danger?: boolean;
}) {
  return (
    <button
      title={title}
      onClick={onClick}
      className={`rounded-md p-2 hover:bg-white/5 ${danger ? "text-slate-500 hover:text-red-400" : "text-slate-500 hover:text-slate-200"}`}
    >
      {children}
    </button>
  );
}

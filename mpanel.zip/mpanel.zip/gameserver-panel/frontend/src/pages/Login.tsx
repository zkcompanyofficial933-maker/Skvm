import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { Box, Loader2 } from "lucide-react";
import { useAuthStore } from "../store/auth.store";
import Button from "../components/ui/Button";

export default function Login() {
  const [mode, setMode] = useState<"login" | "register">("login");
  const [identifier, setIdentifier] = useState("");
  const [email, setEmail] = useState("");
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const login = useAuthStore((s) => s.login);
  const register = useAuthStore((s) => s.register);
  const navigate = useNavigate();

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      if (mode === "login") await login(identifier, password);
      else await register(email, username, password);
      navigate("/");
    } catch (err: any) {
      setError(err.response?.data?.error ?? "Something went wrong");
    } finally {
      setLoading(false);
    }
  }

  return (
    <div className="flex min-h-screen items-center justify-center p-4">
      <div className="w-full max-w-sm">
        <div className="mb-8 flex flex-col items-center gap-3">
          <div className="flex h-12 w-12 items-center justify-center rounded-xl bg-accent shadow-glow">
            <Box size={24} className="text-white" />
          </div>
          <h1 className="text-lg font-semibold text-slate-100">NovaPanel</h1>
          <p className="text-sm text-slate-500">Minecraft server hosting, simplified.</p>
        </div>

        <div className="glass rounded-2xl p-6">
          <div className="mb-5 flex rounded-lg bg-base-800/60 p-1">
            <button
              onClick={() => setMode("login")}
              className={`flex-1 rounded-md py-1.5 text-sm font-medium transition-colors ${mode === "login" ? "bg-accent text-white" : "text-slate-400"}`}
            >
              Sign in
            </button>
            <button
              onClick={() => setMode("register")}
              className={`flex-1 rounded-md py-1.5 text-sm font-medium transition-colors ${mode === "register" ? "bg-accent text-white" : "text-slate-400"}`}
            >
              Create account
            </button>
          </div>

          <form onSubmit={submit} className="space-y-3">
            {mode === "login" ? (
              <input
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="Email or username"
                className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-accent/50"
              />
            ) : (
              <>
                <input
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Email"
                  type="email"
                  className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-accent/50"
                />
                <input
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Username"
                  className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-accent/50"
                />
              </>
            )}
            <input
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Password"
              type="password"
              className="w-full rounded-lg border border-white/5 bg-base-800 px-3 py-2.5 text-sm text-slate-100 outline-none focus:border-accent/50"
            />
            {error && <p className="text-xs text-red-400">{error}</p>}
            <Button type="submit" className="w-full" disabled={loading}>
              {loading ? <Loader2 size={14} className="animate-spin" /> : mode === "login" ? "Sign in" : "Create account"}
            </Button>
          </form>
        </div>
        <p className="mt-4 text-center text-xs text-slate-600">
          First account registered on a fresh install automatically becomes the admin.
        </p>
      </div>
    </div>
  );
}

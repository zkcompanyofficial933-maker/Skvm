import { useEffect, useRef, useCallback, useState } from "react";
import { wsUrl } from "../lib/api";
import type { WsClientMessage, WsServerMessage, ContainerStats, ServerStatus } from "../types";

interface UseServerSocketOptions {
  serverId: string;
  onConsoleLine?: (line: string, timestamp: number) => void;
  onStats?: (stats: ContainerStats) => void;
  onStatus?: (status: ServerStatus) => void;
}

/**
 * Opens (or reuses) a WebSocket connection to the gateway, authenticates with
 * the stored JWT, subscribes to a single server's console + stats stream, and
 * exposes helpers to send commands / power actions. Cleans up on unmount.
 */
export function useServerSocket({ serverId, onConsoleLine, onStats, onStatus }: UseServerSocketOptions) {
  const socketRef = useRef<WebSocket | null>(null);
  const [connected, setConnected] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("gsp_token");
    if (!token || !serverId) return;

    const socket = new WebSocket(wsUrl());
    socketRef.current = socket;

    socket.onopen = () => {
      send({ event: "auth", token });
    };

    socket.onmessage = (e) => {
      const msg: WsServerMessage = JSON.parse(e.data);
      switch (msg.event) {
        case "auth:success":
          setConnected(true);
          send({ event: "subscribe", serverId });
          break;
        case "auth:error":
          setConnected(false);
          break;
        case "console:output":
          if (msg.serverId === serverId) onConsoleLine?.(msg.line, msg.timestamp);
          break;
        case "stats:update":
          if (msg.serverId === serverId) onStats?.(msg.stats);
          break;
        case "status:update":
          if (msg.serverId === serverId) onStatus?.(msg.status);
          break;
      }
    };

    socket.onclose = () => setConnected(false);

    function send(message: WsClientMessage) {
      if (socket.readyState === WebSocket.OPEN) socket.send(JSON.stringify(message));
    }

    return () => {
      if (socket.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ event: "unsubscribe", serverId }));
      }
      socket.close();
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [serverId]);

  const sendCommand = useCallback(
    (command: string) => {
      const socket = socketRef.current;
      if (socket?.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ event: "console:command", serverId, command }));
      }
    },
    [serverId]
  );

  const sendPowerAction = useCallback(
    (action: "start" | "stop" | "restart" | "kill") => {
      const socket = socketRef.current;
      if (socket?.readyState === WebSocket.OPEN) {
        socket.send(JSON.stringify({ event: "power:action", serverId, action }));
      }
    },
    [serverId]
  );

  return { connected, sendCommand, sendPowerAction };
}

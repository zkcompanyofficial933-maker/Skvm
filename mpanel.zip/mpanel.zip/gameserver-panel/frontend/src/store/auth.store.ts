import { create } from "zustand";
import { api } from "../lib/api";
import type { AuthUser } from "../types";

interface AuthState {
  user: AuthUser | null;
  token: string | null;
  isLoading: boolean;
  login: (identifier: string, password: string) => Promise<void>;
  register: (email: string, username: string, password: string) => Promise<void>;
  logout: () => void;
  hydrate: () => Promise<void>;
}

export const useAuthStore = create<AuthState>((set) => ({
  user: null,
  token: localStorage.getItem("gsp_token"),
  isLoading: true,

  login: async (identifier, password) => {
    const { data } = await api.post("/auth/login", { identifier, password });
    localStorage.setItem("gsp_token", data.token);
    set({ user: data.user, token: data.token });
  },

  register: async (email, username, password) => {
    const { data } = await api.post("/auth/register", { email, username, password });
    localStorage.setItem("gsp_token", data.token);
    set({ user: data.user, token: data.token });
  },

  logout: () => {
    localStorage.removeItem("gsp_token");
    set({ user: null, token: null });
  },

  hydrate: async () => {
    const token = localStorage.getItem("gsp_token");
    if (!token) return set({ isLoading: false });
    try {
      const { data } = await api.get("/auth/me");
      set({ user: data.user, isLoading: false });
    } catch {
      localStorage.removeItem("gsp_token");
      set({ user: null, token: null, isLoading: false });
    }
  },
}));

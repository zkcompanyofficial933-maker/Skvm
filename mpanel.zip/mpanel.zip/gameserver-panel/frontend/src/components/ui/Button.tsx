import { ButtonHTMLAttributes, forwardRef } from "react";
import clsx from "clsx";

interface ButtonProps extends ButtonHTMLAttributes<HTMLButtonElement> {
  variant?: "primary" | "secondary" | "danger" | "ghost";
  size?: "sm" | "md";
}

const Button = forwardRef<HTMLButtonElement, ButtonProps>(
  ({ className, variant = "primary", size = "md", ...props }, ref) => {
    return (
      <button
        ref={ref}
        className={clsx(
          "inline-flex items-center justify-center gap-2 rounded-lg font-medium transition-colors focus-ring disabled:opacity-50 disabled:pointer-events-none",
          size === "sm" ? "px-3 py-1.5 text-xs" : "px-4 py-2 text-sm",
          variant === "primary" && "bg-accent text-white hover:bg-accent-hover",
          variant === "secondary" && "bg-base-750 text-slate-200 hover:bg-base-700 border border-white/5",
          variant === "danger" && "bg-red-500/10 text-red-400 hover:bg-red-500/20 border border-red-500/20",
          variant === "ghost" && "text-slate-400 hover:text-slate-100 hover:bg-white/5",
          className
        )}
        {...props}
      />
    );
  }
);
Button.displayName = "Button";
export default Button;

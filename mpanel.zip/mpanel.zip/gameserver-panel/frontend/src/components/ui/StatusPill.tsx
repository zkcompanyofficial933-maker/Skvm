import clsx from "clsx";
import type { ServerStatus } from "../../types";

const CONFIG: Record<ServerStatus, { label: string; dot: string; text: string; bg: string }> = {
  RUNNING: { label: "Running", dot: "bg-status-running", text: "text-status-running", bg: "bg-status-running/10" },
  STARTING: { label: "Starting", dot: "bg-status-starting", text: "text-status-starting", bg: "bg-status-starting/10" },
  STOPPING: { label: "Stopping", dot: "bg-status-starting", text: "text-status-starting", bg: "bg-status-starting/10" },
  INSTALLING: { label: "Installing", dot: "bg-status-starting", text: "text-status-starting", bg: "bg-status-starting/10" },
  OFFLINE: { label: "Offline", dot: "bg-status-offline", text: "text-status-offline", bg: "bg-status-offline/10" },
  CRASHED: { label: "Crashed", dot: "bg-status-error", text: "text-status-error", bg: "bg-status-error/10" },
  SUSPENDED: { label: "Suspended", dot: "bg-status-error", text: "text-status-error", bg: "bg-status-error/10" },
};

export default function StatusPill({ status }: { status: ServerStatus }) {
  const c = CONFIG[status];
  const pulsing = status === "STARTING" || status === "STOPPING" || status === "INSTALLING";
  return (
    <span className={clsx("inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-medium", c.bg, c.text)}>
      <span className={clsx("h-1.5 w-1.5 rounded-full", c.dot, pulsing && "animate-pulse")} />
      {c.label}
    </span>
  );
}

import { useEffect, useState, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { Search, Wifi, ChevronDown, LogOut, User as UserIcon } from "lucide-react";
import { AnimatePresence, motion } from "framer-motion";
import { useAuthStore } from "../../store/auth.store";
import { api } from "../../lib/api";
import type { GameServer } from "../../types";

function useBreadcrumbs() {
  const { pathname } = useLocation();
  const parts = pathname.split("/").filter(Boolean);
  if (parts.length === 0) return ["Dashboard"];
  return parts.map((p) => p.charAt(0).toUpperCase() + p.slice(1));
}

export default function Header() {
  const crumbs = useBreadcrumbs();
  const user = useAuthStore((s) => s.user);
  const logout = useAuthStore((s) => s.logout);
  const navigate = useNavigate();

  const [searchOpen, setSearchOpen] = useState(false);
  const [query, setQuery] = useState("");
  const [servers, setServers] = useState<GameServer[]>([]);
  const [profileOpen, setProfileOpen] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    function onKeyDown(e: KeyboardEvent) {
      if ((e.metaKey || e.ctrlKey) && e.key.toLowerCase() === "k") {
        e.preventDefault();
        setSearchOpen(true);
      }
      if (e.key === "Escape") setSearchOpen(false);
    }
    window.addEventListener("keydown", onKeyDown);
    return () => window.removeEventListener("keydown", onKeyDown);
  }, []);

  useEffect(() => {
    if (searchOpen) {
      api.get("/servers").then((r) => setServers(r.data.servers));
      setTimeout(() => inputRef.current?.focus(), 50);
    }
  }, [searchOpen]);

  const filtered = servers.filter((s) => s.name.toLowerCase().includes(query.toLowerCase()));

  return (
    <>
      <header className="flex h-14 items-center justify-between border-b border-white/5 bg-base-900/60 px-6 backdrop-blur-xl">
        <div className="flex items-center gap-2 text-sm text-slate-400">
          {crumbs.map((c, i) => (
            <span key={i} className="flex items-center gap-2">
              {i > 0 && <span className="text-slate-600">/</span>}
              <span className={i === crumbs.length - 1 ? "text-slate-100" : ""}>{c}</span>
            </span>
          ))}
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setSearchOpen(true)}
            className="flex items-center gap-2 rounded-lg border border-white/5 bg-base-800/60 px-3 py-1.5 text-xs text-slate-500 hover:border-white/10 hover:text-slate-300 focus-ring"
          >
            <Search size={14} />
            <span>Quick search</span>
            <kbd className="rounded border border-white/10 bg-base-750 px-1.5 py-0.5 font-mono text-[10px]">⌘K</kbd>
          </button>

          <div className="flex items-center gap-1.5 text-xs text-status-running">
            <Wifi size={14} />
            <span>All nodes online</span>
          </div>

          <div className="relative">
            <button
              onClick={() => setProfileOpen((o) => !o)}
              className="flex items-center gap-2 rounded-lg px-2 py-1.5 hover:bg-white/5 focus-ring"
            >
              <div className="flex h-7 w-7 items-center justify-center rounded-full bg-accent/20 text-xs font-semibold text-accent-hover">
                {user?.username?.slice(0, 2).toUpperCase()}
              </div>
              <ChevronDown size={14} className="text-slate-500" />
            </button>
            <AnimatePresence>
              {profileOpen && (
                <motion.div
                  initial={{ opacity: 0, y: -4 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -4 }}
                  className="glass absolute right-0 top-11 w-48 rounded-lg p-1 shadow-glass"
                >
                  <div className="px-3 py-2 text-xs text-slate-500">
                    Signed in as <span className="text-slate-200">{user?.username}</span>
                  </div>
                  <button className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-slate-300 hover:bg-white/5">
                    <UserIcon size={14} /> Profile settings
                  </button>
                  <button
                    onClick={logout}
                    className="flex w-full items-center gap-2 rounded-md px-3 py-2 text-sm text-red-400 hover:bg-red-500/10"
                  >
                    <LogOut size={14} /> Sign out
                  </button>
                </motion.div>
              )}
            </AnimatePresence>
          </div>
        </div>
      </header>

      <AnimatePresence>
        {searchOpen && (
          <div className="fixed inset-0 z-50 flex items-start justify-center pt-24" onClick={() => setSearchOpen(false)}>
            <motion.div className="absolute inset-0 bg-black/60 backdrop-blur-sm" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} />
            <motion.div
              initial={{ opacity: 0, scale: 0.97, y: -8 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.97, y: -8 }}
              transition={{ duration: 0.12 }}
              onClick={(e) => e.stopPropagation()}
              className="glass relative w-full max-w-lg rounded-xl shadow-glass"
            >
              <div className="flex items-center gap-3 border-b border-white/5 px-4 py-3">
                <Search size={16} className="text-slate-500" />
                <input
                  ref={inputRef}
                  value={query}
                  onChange={(e) => setQuery(e.target.value)}
                  placeholder="Jump to a server..."
                  className="flex-1 bg-transparent text-sm text-slate-100 outline-none placeholder:text-slate-600"
                />
              </div>
              <div className="max-h-72 overflow-y-auto p-2">
                {filtered.length === 0 && <p className="px-3 py-4 text-sm text-slate-600">No servers found</p>}
                {filtered.map((s) => (
                  <button
                    key={s.id}
                    onClick={() => {
                      navigate(`/servers/${s.id}/console`);
                      setSearchOpen(false);
                      setQuery("");
                    }}
                    className="flex w-full items-center justify-between rounded-lg px-3 py-2 text-left text-sm text-slate-300 hover:bg-white/5"
                  >
                    <span>{s.name}</span>
                    <span className="text-xs text-slate-600">{s.image}</span>
                  </button>
                ))}
              </div>
            </motion.div>
          </div>
        )}
      </AnimatePresence>
    </>
  );
}

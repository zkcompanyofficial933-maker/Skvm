import { NavLink } from "react-router-dom";
import { useState } from "react";
import clsx from "clsx";
import {
  LayoutDashboard,
  Server,
  HardDrive,
  Users,
  KeyRound,
  ChevronsLeft,
  ChevronsRight,
  Box,
} from "lucide-react";
import { useAuthStore } from "../../store/auth.store";

const NAV_ITEMS = [
  { to: "/", label: "Dashboard", icon: LayoutDashboard, end: true },
  { to: "/servers", label: "Servers", icon: Server },
  { to: "/nodes", label: "Host Nodes", icon: HardDrive, adminOnly: true },
  { to: "/users", label: "User Access", icon: Users, adminOnly: true },
  { to: "/api-keys", label: "API Keys", icon: KeyRound },
];

export default function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const user = useAuthStore((s) => s.user);

  return (
    <aside
      className={clsx(
        "flex h-screen flex-col border-r border-white/5 bg-base-900/80 backdrop-blur-xl transition-all duration-200",
        collapsed ? "w-16" : "w-60"
      )}
    >
      <div className="flex h-14 items-center gap-2 border-b border-white/5 px-4">
        <div className="flex h-7 w-7 shrink-0 items-center justify-center rounded-md bg-accent shadow-glow">
          <Box size={16} className="text-white" />
        </div>
        {!collapsed && <span className="font-semibold tracking-tight text-slate-100">NovaPanel</span>}
      </div>

      <nav className="flex-1 space-y-1 overflow-y-auto p-3">
        {NAV_ITEMS.filter((item) => !item.adminOnly || user?.role === "ADMIN").map((item) => (
          <NavLink
            key={item.to}
            to={item.to}
            end={item.end}
            className={({ isActive }) =>
              clsx(
                "flex items-center gap-3 rounded-lg px-3 py-2 text-sm font-medium transition-colors focus-ring",
                isActive
                  ? "bg-accent/15 text-accent-hover"
                  : "text-slate-400 hover:bg-white/5 hover:text-slate-200"
              )
            }
          >
            <item.icon size={18} className="shrink-0" />
            {!collapsed && <span>{item.label}</span>}
          </NavLink>
        ))}
      </nav>

      <button
        onClick={() => setCollapsed((c) => !c)}
        className="flex items-center gap-2 border-t border-white/5 px-4 py-3 text-xs text-slate-500 hover:bg-white/5 hover:text-slate-300 focus-ring"
      >
        {collapsed ? <ChevronsRight size={16} /> : <ChevronsLeft size={16} />}
        {!collapsed && "Collapse"}
      </button>
    </aside>
  );
}

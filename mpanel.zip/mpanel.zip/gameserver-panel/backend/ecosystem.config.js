// PM2 process manager config
module.exports = {
  apps: [
    {
      name: "gsp-backend",
      script: "dist/server.js",
      instances: 1,
      exec_mode: "fork",
      env: {
        NODE_ENV: "production",
        PORT: 8080,
      },
      max_memory_restart: "500M",
      watch: false,
      autorestart: true,
    },
  ],
};

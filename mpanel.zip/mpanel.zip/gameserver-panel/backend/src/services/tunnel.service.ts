import fetch from "node-fetch";
import { env } from "../config/env";
import { prisma } from "../lib/prisma";
import { logger } from "../utils/logger";

/**
 * Manages playit.gg tunnels so servers get a public address without manual
 * router port-forwarding. In production this talks to the playit.gg control
 * API using an account/agent secret provisioned per node; the shape below
 * models the request/response flow described in playit's API docs.
 */
export class TunnelService {
  private base = env.PLAYIT_API_BASE;

  async createTunnel(serverId: string, localPort: number, agentSecret: string) {
    const server = await prisma.server.findUniqueOrThrow({ where: { id: serverId } });

    const tunnelRecord = await prisma.tunnel.create({
      data: { serverId, localPort, status: "pending" },
    });

    try {
      const res = await fetch(`${this.base}/tunnels`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${agentSecret}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          name: `gsp-${server.uuid}`,
          local_port: localPort,
          tunnel_type: "tcp",
        }),
      });

      if (!res.ok) throw new Error(`playit.gg API error: ${res.status}`);
      const data: any = await res.json();

      return prisma.tunnel.update({
        where: { id: tunnelRecord.id },
        data: {
          tunnelId: data.id,
          publicAddress: data.assigned_domain ?? data.address,
          status: "active",
        },
      });
    } catch (err) {
      logger.error("Failed to create playit.gg tunnel", err);
      return prisma.tunnel.update({ where: { id: tunnelRecord.id }, data: { status: "error" } });
    }
  }

  async deleteTunnel(tunnelDbId: string, agentSecret: string) {
    const tunnel = await prisma.tunnel.findUniqueOrThrow({ where: { id: tunnelDbId } });
    if (tunnel.tunnelId) {
      await fetch(`${this.base}/tunnels/${tunnel.tunnelId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${agentSecret}` },
      }).catch((err) => logger.error("Failed to delete playit.gg tunnel", err));
    }
    await prisma.tunnel.update({ where: { id: tunnelDbId }, data: { status: "disabled" } });
  }

  async getStatus(serverId: string) {
    return prisma.tunnel.findMany({ where: { serverId } });
  }
}

export const tunnelService = new TunnelService();

import Docker from "dockerode";
import { Readable, PassThrough } from "stream";
import { env } from "../config/env";
import { logger } from "../utils/logger";
import type { ContainerStats, PowerAction } from "../types";

/**
 * DockerService wraps the Docker Engine API (via dockerode) to provide
 * game-server-specific container lifecycle operations: creation with
 * resource limits, power actions, live log/exec streaming, and stats polling.
 */
export class DockerService {
  private docker: Docker;

  constructor(socketPath: string = env.DOCKER_SOCKET) {
    this.docker = new Docker({ socketPath });
  }

  /** Creates a new container for a game server with resource + network constraints */
  async createServerContainer(opts: {
    name: string;
    image: string; // e.g. "itzg/minecraft-server:latest"
    envVars: Record<string, string>;
    memoryLimitMb: number;
    cpuCores: number;
    diskLimitMb: number;
    primaryPort: number;
    additionalPorts: number[];
    volumePath: string; // host path bound to the server's data directory
    startupCommand?: string;
  }) {
    const memoryBytes = opts.memoryLimitMb * 1024 * 1024;
    const nanoCpus = Math.floor(opts.cpuCores * 1e9);

    const portBindings: Record<string, { HostPort: string }[]> = {};
    const exposedPorts: Record<string, {}> = {};
    const allPorts = [opts.primaryPort, ...opts.additionalPorts];
    for (const port of allPorts) {
      const key = `${port}/tcp`;
      exposedPorts[key] = {};
      portBindings[key] = [{ HostPort: String(port) }];
      // Most game servers also need the matching UDP port (e.g. voice/query)
      const udpKey = `${port}/udp`;
      exposedPorts[udpKey] = {};
      portBindings[udpKey] = [{ HostPort: String(port) }];
    }

    const container = await this.docker.createContainer({
      name: opts.name,
      Image: `${opts.image}`,
      Tty: true,
      OpenStdin: true,
      Env: Object.entries(opts.envVars).map(([k, v]) => `${k}=${v}`),
      ExposedPorts: exposedPorts,
      Cmd: opts.startupCommand ? opts.startupCommand.split(" ") : undefined,
      HostConfig: {
        Memory: memoryBytes,
        MemorySwap: memoryBytes, // disable extra swap beyond RAM limit by default
        NanoCpus: nanoCpus,
        PortBindings: portBindings,
        Binds: [`${opts.volumePath}:/data`],
        RestartPolicy: { Name: "unless-stopped" },
        // Disk quota enforcement depends on the storage driver (overlay2 + xfs pquota, etc.)
        // Real deployments should mount a pre-quota'd volume at opts.volumePath.
      },
      Labels: {
        "gsp.managed": "true",
      },
    });

    return container;
  }

  async powerAction(containerId: string, action: PowerAction): Promise<void> {
    const container = this.docker.getContainer(containerId);
    switch (action) {
      case "start":
        await container.start();
        break;
      case "stop":
        await container.stop({ t: 30 }); // graceful 30s shutdown window
        break;
      case "restart":
        await container.restart({ t: 30 });
        break;
      case "kill":
        await container.kill();
        break;
    }
  }

  async removeContainer(containerId: string): Promise<void> {
    const container = this.docker.getContainer(containerId);
    await container.remove({ force: true });
  }

  async inspect(containerId: string) {
    return this.docker.getContainer(containerId).inspect();
  }

  /**
   * Attaches to a running container's stdio stream for live console output.
   * Returns a readable stream of combined stdout/stderr bytes.
   */
  async attachConsole(containerId: string): Promise<NodeJS.ReadableStream> {
    const container = this.docker.getContainer(containerId);
    const stream = await container.attach({
      stream: true,
      stdout: true,
      stderr: true,
      stdin: false,
    });
    return stream;
  }

  /**
   * Executes an interactive command inside the container (used for the
   * in-panel terminal and for sending console commands like "say hello").
   */
  async execCommand(containerId: string, command: string): Promise<PassThrough> {
    const container = this.docker.getContainer(containerId);
    const exec = await container.exec({
      Cmd: ["/bin/sh", "-c", command],
      AttachStdout: true,
      AttachStderr: true,
      Tty: true,
    });
    const stream = await exec.start({ hijack: true, stdin: false });
    const out = new PassThrough();
    stream.pipe(out);
    return out;
  }

  /**
   * Writes directly to a container's stdin — this is how console commands
   * (e.g. Minecraft's "/say", "/stop") get delivered to a foreground process.
   */
  async sendStdin(containerId: string, input: string): Promise<void> {
    const container = this.docker.getContainer(containerId);
    const stream = await container.attach({ stream: true, stdin: true, hijack: true });
    stream.write(input.endsWith("\n") ? input : `${input}\n`);
  }

  /** Polls live resource stats (CPU %, memory, network IO) for a container */
  async getStats(containerId: string, serverId: string): Promise<ContainerStats> {
    const container = this.docker.getContainer(containerId);
    const stats: any = await container.stats({ stream: false });
    const info = await container.inspect();

    const cpuDelta = stats.cpu_stats.cpu_usage.total_usage - stats.precpu_stats.cpu_usage.total_usage;
    const systemDelta = stats.cpu_stats.system_cpu_usage - stats.precpu_stats.system_cpu_usage;
    const cpuCount = stats.cpu_stats.online_cpus || 1;
    const cpuPercent = systemDelta > 0 ? (cpuDelta / systemDelta) * cpuCount * 100 : 0;

    const memoryUsedMb = (stats.memory_stats.usage ?? 0) / 1024 / 1024;
    const memoryLimitMb = (stats.memory_stats.limit ?? 0) / 1024 / 1024;

    let rx = 0;
    let tx = 0;
    if (stats.networks) {
      for (const iface of Object.values<any>(stats.networks)) {
        rx += iface.rx_bytes ?? 0;
        tx += iface.tx_bytes ?? 0;
      }
    }

    const startedAt = new Date(info.State.StartedAt).getTime();
    const uptimeSeconds = info.State.Running ? Math.max(0, (Date.now() - startedAt) / 1000) : 0;

    return {
      serverId,
      cpuPercent: Math.round(cpuPercent * 100) / 100,
      memoryUsedMb: Math.round(memoryUsedMb),
      memoryLimitMb: Math.round(memoryLimitMb),
      diskUsedMb: 0, // populated by FileService.getDirectorySize() for the volume path
      networkRxBytes: rx,
      networkTxBytes: tx,
      uptimeSeconds: Math.round(uptimeSeconds),
      timestamp: Date.now(),
    };
  }

  async listManagedContainers() {
    return this.docker.listContainers({ all: true, filters: JSON.stringify({ label: ["gsp.managed=true"] }) });
  }
}

export const dockerService = new DockerService();

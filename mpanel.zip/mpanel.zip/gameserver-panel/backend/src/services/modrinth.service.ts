import fetch from "node-fetch";
import { env } from "../config/env";

/**
 * Thin client over the Modrinth API for plugin/mod search + auto-installation.
 * Docs: https://docs.modrinth.com/
 */
export class ModrinthService {
  private base = env.MODRINTH_API_BASE;

  async search(query: string, opts: { facets?: string[][]; limit?: number; offset?: number } = {}) {
    const params = new URLSearchParams();
    params.set("query", query);
    params.set("limit", String(opts.limit ?? 20));
    params.set("offset", String(opts.offset ?? 0));
    if (opts.facets) params.set("facets", JSON.stringify(opts.facets));

    const res = await fetch(`${this.base}/search?${params.toString()}`);
    if (!res.ok) throw new Error(`Modrinth search failed: ${res.status}`);
    return res.json();
  }

  async getProject(idOrSlug: string) {
    const res = await fetch(`${this.base}/project/${idOrSlug}`);
    if (!res.ok) throw new Error(`Modrinth project fetch failed: ${res.status}`);
    return res.json();
  }

  async getVersions(idOrSlug: string, opts: { loaders?: string[]; gameVersions?: string[] } = {}) {
    const params = new URLSearchParams();
    if (opts.loaders) params.set("loaders", JSON.stringify(opts.loaders));
    if (opts.gameVersions) params.set("game_versions", JSON.stringify(opts.gameVersions));
    const res = await fetch(`${this.base}/project/${idOrSlug}/version?${params.toString()}`);
    if (!res.ok) throw new Error(`Modrinth versions fetch failed: ${res.status}`);
    return res.json();
  }

  /** Returns the primary downloadable file URL + filename for a given version id */
  async getVersionFile(versionId: string): Promise<{ url: string; filename: string; sizeBytes: number }> {
    const res = await fetch(`${this.base}/version/${versionId}`);
    if (!res.ok) throw new Error(`Modrinth version fetch failed: ${res.status}`);
    const data: any = await res.json();
    const primary = data.files.find((f: any) => f.primary) ?? data.files[0];
    return { url: primary.url, filename: primary.filename, sizeBytes: primary.size };
  }

  async downloadVersionFile(url: string): Promise<Buffer> {
    const res = await fetch(url);
    if (!res.ok) throw new Error(`Failed to download mod file: ${res.status}`);
    return Buffer.from(await res.arrayBuffer());
  }
}

export const modrinthService = new ModrinthService();

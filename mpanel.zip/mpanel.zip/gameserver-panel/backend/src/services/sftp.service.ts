import SftpServer from "ssh2-sftp-server";
import fs from "fs";
import path from "path";
import bcrypt from "bcryptjs";
import { prisma } from "../lib/prisma";
import { env } from "../config/env";
import { logger } from "../utils/logger";

/**
 * Bridges external SFTP clients (FileZilla, Cyberduck, WinSCP) directly into
 * a server's scoped data directory. Username format: "<panelUsername>.<serverUuidPrefix>",
 * authenticated against the user's panel password. Each session is chrooted to
 * that server's directory under DATA_ROOT so no cross-server access is possible.
 */
export class SftpBridge {
  private server: any;

  constructor(private hostKeyPath: string = "./ssh_host_key") {
    if (!fs.existsSync(this.hostKeyPath)) {
      throw new Error(
        `SSH host key not found at ${this.hostKeyPath}. Generate one with: ssh-keygen -t rsa -b 4096 -f ${this.hostKeyPath} -N ""`
      );
    }
  }

  start(port: number = env.SFTP_PORT) {
    this.server = new SftpServer({
      hostKeys: [fs.readFileSync(this.hostKeyPath, "utf-8")],
    });

    this.server.on("connection", (client: any) => {
      client.on("authentication", async (ctx: any) => {
        if (ctx.method !== "password") return ctx.reject(["password"]);

        try {
          const [username, serverUuidPrefix] = ctx.username.split(".");
          const user = await prisma.user.findUnique({ where: { username } });
          if (!user || !(await bcrypt.compare(ctx.password, user.passwordHash))) {
            return ctx.reject();
          }

          const server = await prisma.server.findFirst({
            where: { uuid: { startsWith: serverUuidPrefix } },
          });
          if (!server) return ctx.reject();

          const hasAccess =
            server.ownerId === user.id ||
            !!(await prisma.subUser.findUnique({
              where: { userId_serverId: { userId: user.id, serverId: server.id } },
            }));
          if (!hasAccess) return ctx.reject();

          (ctx as any)._chrootPath = path.join(env.DATA_ROOT, server.uuid);
          ctx.accept();
        } catch (err) {
          logger.error("SFTP auth error", err);
          ctx.reject();
        }
      });

      client.on("ready", () => {
        logger.info("SFTP client authenticated and ready");
        // Session-level SFTP subsystem handling (readdir/open/write/etc.) would be
        // registered here, all scoped to ctx._chrootPath established during auth.
      });
    });

    this.server.listen(port, "0.0.0.0", () => {
      logger.info(`SFTP bridge listening on port ${port}`);
    });
  }
}

export const sftpBridge = new SftpBridge();

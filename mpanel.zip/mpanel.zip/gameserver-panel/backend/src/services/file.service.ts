import fs from "fs/promises";
import fsSync from "fs";
import path from "path";
import tar from "tar";
import { env } from "../config/env";
import type { FileNode } from "../types";

/**
 * FileService scopes every operation to a server's data root
 * (env.DATA_ROOT/<serverUuid>) and defends against path traversal.
 */
export class FileService {
  private rootFor(serverUuid: string): string {
    return path.join(env.DATA_ROOT, serverUuid);
  }

  /** Resolves a user-supplied relative path and guarantees it stays inside the server root */
  private safeResolve(serverUuid: string, relativePath: string): string {
    const root = this.rootFor(serverUuid);
    const resolved = path.resolve(root, `.${path.sep}${relativePath}`);
    if (!resolved.startsWith(root)) {
      throw new Error("Path traversal detected — access denied");
    }
    return resolved;
  }

  async ensureRoot(serverUuid: string) {
    await fs.mkdir(this.rootFor(serverUuid), { recursive: true });
  }

  async listDirectory(serverUuid: string, relativePath = "/"): Promise<FileNode[]> {
    const dirPath = this.safeResolve(serverUuid, relativePath);
    const entries = await fs.readdir(dirPath, { withFileTypes: true });

    const nodes = await Promise.all(
      entries.map(async (entry): Promise<FileNode> => {
        const fullPath = path.join(dirPath, entry.name);
        const stat = await fs.stat(fullPath);
        return {
          name: entry.name,
          path: path.join(relativePath, entry.name).replace(/\\/g, "/"),
          type: entry.isDirectory() ? "directory" : "file",
          size: stat.size,
          modifiedAt: stat.mtime.toISOString(),
          mimeType: entry.isFile() ? guessMime(entry.name) : undefined,
        };
      })
    );

    // Directories first, then alphabetical
    return nodes.sort((a, b) =>
      a.type === b.type ? a.name.localeCompare(b.name) : a.type === "directory" ? -1 : 1
    );
  }

  async readFile(serverUuid: string, relativePath: string): Promise<string> {
    const filePath = this.safeResolve(serverUuid, relativePath);
    return fs.readFile(filePath, "utf-8");
  }

  async writeFile(serverUuid: string, relativePath: string, content: string): Promise<void> {
    const filePath = this.safeResolve(serverUuid, relativePath);
    await fs.mkdir(path.dirname(filePath), { recursive: true });
    await fs.writeFile(filePath, content, "utf-8");
  }

  async rename(serverUuid: string, fromPath: string, toPath: string): Promise<void> {
    const from = this.safeResolve(serverUuid, fromPath);
    const to = this.safeResolve(serverUuid, toPath);
    await fs.rename(from, to);
  }

  async move(serverUuid: string, fromPath: string, toPath: string): Promise<void> {
    return this.rename(serverUuid, fromPath, toPath);
  }

  async delete(serverUuid: string, relativePath: string): Promise<void> {
    const target = this.safeResolve(serverUuid, relativePath);
    await fs.rm(target, { recursive: true, force: true });
  }

  async mkdir(serverUuid: string, relativePath: string): Promise<void> {
    const target = this.safeResolve(serverUuid, relativePath);
    await fs.mkdir(target, { recursive: true });
  }

  async saveUpload(serverUuid: string, relativePath: string, buffer: Buffer): Promise<void> {
    const target = this.safeResolve(serverUuid, relativePath);
    await fs.mkdir(path.dirname(target), { recursive: true });
    await fs.writeFile(target, buffer);
  }

  /** Compresses a directory or file into a .tar.gz archive (used for world/backup exports) */
  async compress(serverUuid: string, relativePath: string, archiveName: string): Promise<string> {
    const source = this.safeResolve(serverUuid, relativePath);
    const destination = this.safeResolve(serverUuid, archiveName);
    await tar.c({ gzip: true, file: destination, cwd: path.dirname(source) }, [path.basename(source)]);
    return archiveName;
  }

  /** Extracts a .tar.gz/.zip archive in place (used for world restore + mod installs) */
  async extract(serverUuid: string, archiveRelativePath: string, destRelativePath = "/"): Promise<void> {
    const archivePath = this.safeResolve(serverUuid, archiveRelativePath);
    const destPath = this.safeResolve(serverUuid, destRelativePath);
    await fs.mkdir(destPath, { recursive: true });
    await tar.x({ file: archivePath, cwd: destPath });
  }

  /** Recursively computes total size in MB — used to populate disk usage stats */
  async getDirectorySizeMb(serverUuid: string): Promise<number> {
    const root = this.rootFor(serverUuid);
    let total = 0;
    async function walk(dir: string) {
      const entries = await fs.readdir(dir, { withFileTypes: true });
      for (const entry of entries) {
        const full = path.join(dir, entry.name);
        if (entry.isDirectory()) await walk(full);
        else total += (await fs.stat(full)).size;
      }
    }
    if (fsSync.existsSync(root)) await walk(root);
    return Math.round(total / 1024 / 1024);
  }
}

function guessMime(filename: string): string {
  const ext = path.extname(filename).toLowerCase();
  const map: Record<string, string> = {
    ".txt": "text/plain",
    ".log": "text/plain",
    ".json": "application/json",
    ".yml": "application/x-yaml",
    ".yaml": "application/x-yaml",
    ".properties": "text/plain",
    ".jar": "application/java-archive",
    ".zip": "application/zip",
    ".png": "image/png",
    ".jpg": "image/jpeg",
  };
  return map[ext] ?? "application/octet-stream";
}

export const fileService = new FileService();

// Shared domain types used across the backend (mirrors frontend /src/types)

export type Role = "ADMIN" | "USER";

export type ServerStatus =
  | "INSTALLING"
  | "OFFLINE"
  | "STARTING"
  | "RUNNING"
  | "STOPPING"
  | "CRASHED"
  | "SUSPENDED";

export type NodeStatus = "ONLINE" | "OFFLINE" | "MAINTENANCE";

export interface AuthUser {
  id: string;
  email: string;
  username: string;
  role: Role;
}

export interface JwtPayload {
  sub: string; // user id
  role: Role;
  iat?: number;
  exp?: number;
}

export interface GameServer {
  id: string;
  uuid: string;
  name: string;
  description?: string | null;
  status: ServerStatus;
  containerId?: string | null;
  image: string;
  dockerImageTag: string;
  memoryLimitMb: number;
  cpuLimitCores: number;
  diskLimitMb: number;
  swapLimitMb: number;
  startupCommand: string;
  environment: Record<string, string>;
  nodeId: string;
  ownerId: string;
  primaryPort: number;
  additionalPorts: number[];
  createdAt: string;
  updatedAt: string;
}

export interface HostNode {
  id: string;
  name: string;
  fqdn: string;
  status: NodeStatus;
  memoryTotalMb: number;
  diskTotalMb: number;
  cpuCores: number;
  portRangeStart: number;
  portRangeEnd: number;
  location?: string | null;
}

export const PERMISSIONS = [
  "console:read",
  "console:write",
  "power:start",
  "power:stop",
  "power:restart",
  "power:kill",
  "files:read",
  "files:write",
  "files:delete",
  "files:sftp",
  "backups:create",
  "backups:restore",
  "backups:delete",
  "players:manage",
  "plugins:install",
  "settings:update",
  "tunnels:manage",
] as const;

export type Permission = (typeof PERMISSIONS)[number];

export interface SubUserPermissionSet {
  id: string;
  userId: string;
  serverId: string;
  permissions: Permission[];
}

export interface FileNode {
  name: string;
  path: string;
  type: "file" | "directory";
  size: number;
  modifiedAt: string;
  mimeType?: string;
}

export interface ContainerStats {
  serverId: string;
  cpuPercent: number;
  memoryUsedMb: number;
  memoryLimitMb: number;
  diskUsedMb: number;
  networkRxBytes: number;
  networkTxBytes: number;
  uptimeSeconds: number;
  timestamp: number;
}

export type PowerAction = "start" | "stop" | "restart" | "kill";

// Socket message envelope used over the WebSocket gateway
export type WsClientMessage =
  | { event: "auth"; token: string }
  | { event: "subscribe"; serverId: string }
  | { event: "unsubscribe"; serverId: string }
  | { event: "console:command"; serverId: string; command: string }
  | { event: "power:action"; serverId: string; action: PowerAction };

export type WsServerMessage =
  | { event: "auth:success"; user: AuthUser }
  | { event: "auth:error"; message: string }
  | { event: "console:output"; serverId: string; line: string; timestamp: number }
  | { event: "stats:update"; serverId: string; stats: ContainerStats }
  | { event: "status:update"; serverId: string; status: ServerStatus }
  | { event: "error"; message: string };

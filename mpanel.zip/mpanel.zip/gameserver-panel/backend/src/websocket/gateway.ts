import { WebSocketServer, WebSocket } from "ws";
import { Server as HttpServer } from "http";
import { verifyToken } from "../lib/jwt";
import { prisma } from "../lib/prisma";
import { dockerService } from "../services/docker.service";
import { logger } from "../utils/logger";
import type { AuthUser, Permission, WsClientMessage, WsServerMessage } from "../types";

interface Client {
  socket: WebSocket;
  user?: AuthUser;
  subscriptions: Set<string>; // serverIds this socket is subscribed to
}

const STATS_POLL_INTERVAL_MS = 2000;

/**
 * WebSocketGateway is the single bi-directional channel the frontend uses for:
 *  - live console stdout/stderr streaming
 *  - CPU/RAM/network stat ticks
 *  - sending console commands / power actions
 * Auth happens post-connection via an explicit `auth` message carrying the JWT,
 * which keeps the JWT out of the URL/query string (avoids leaking into logs).
 */
export class WebSocketGateway {
  private wss: WebSocketServer;
  private clients = new Set<Client>();
  // serverId -> active docker log stream, shared across subscribers to avoid duplicate attaches
  private consoleStreams = new Map<string, NodeJS.ReadableStream>();
  private statsIntervals = new Map<string, NodeJS.Timeout>();

  constructor(httpServer: HttpServer) {
    this.wss = new WebSocketServer({ server: httpServer, path: "/ws" });
    this.wss.on("connection", (socket) => this.handleConnection(socket));
    logger.info("WebSocket gateway listening on /ws");
  }

  private handleConnection(socket: WebSocket) {
    const client: Client = { socket, subscriptions: new Set() };
    this.clients.add(client);

    socket.on("message", (raw) => this.handleMessage(client, raw.toString()));
    socket.on("close", () => this.handleClose(client));
    socket.on("error", (err) => logger.error("WS socket error", err));
  }

  private send(client: Client, message: WsServerMessage) {
    if (client.socket.readyState === WebSocket.OPEN) {
      client.socket.send(JSON.stringify(message));
    }
  }

  private async handleMessage(client: Client, raw: string) {
    let msg: WsClientMessage;
    try {
      msg = JSON.parse(raw);
    } catch {
      return this.send(client, { event: "error", message: "Malformed JSON payload" });
    }

    switch (msg.event) {
      case "auth":
        return this.handleAuth(client, msg.token);

      case "subscribe":
        return this.handleSubscribe(client, msg.serverId);

      case "unsubscribe":
        client.subscriptions.delete(msg.serverId);
        this.maybeTeardownStreams(msg.serverId);
        return;

      case "console:command":
        return this.handleConsoleCommand(client, msg.serverId, msg.command);

      case "power:action":
        return this.handlePowerAction(client, msg.serverId, msg.action);
    }
  }

  private async handleAuth(client: Client, token: string) {
    try {
      const payload = verifyToken(token);
      const user = await prisma.user.findUnique({ where: { id: payload.sub } });
      if (!user || !user.isActive) throw new Error("inactive");
      client.user = { id: user.id, email: user.email, username: user.username, role: user.role as any };
      this.send(client, { event: "auth:success", user: client.user });
    } catch {
      this.send(client, { event: "auth:error", message: "Invalid or expired token" });
      client.socket.close();
    }
  }

  private async assertAccess(client: Client, serverId: string, permission: Permission): Promise<boolean> {
    if (!client.user) return false;
    if (client.user.role === "ADMIN") return true;

    const server = await prisma.server.findUnique({ where: { id: serverId } });
    if (!server) return false;
    if (server.ownerId === client.user.id) return true;

    const subUser = await prisma.subUser.findUnique({
      where: { userId_serverId: { userId: client.user.id, serverId } },
    });
    if (!subUser) return false;
    const perms: Permission[] = JSON.parse(subUser.permissions);
    return perms.includes(permission);
  }

  private async handleSubscribe(client: Client, serverId: string) {
    const allowed = await this.assertAccess(client, serverId, "console:read");
    if (!allowed) return this.send(client, { event: "error", message: "Access denied to server console" });

    client.subscriptions.add(serverId);
    await this.ensureConsoleStream(serverId);
    this.ensureStatsPolling(serverId);
  }

  /** Attaches once per server and fans out output to every subscribed client */
  private async ensureConsoleStream(serverId: string) {
    if (this.consoleStreams.has(serverId)) return;

    const server = await prisma.server.findUnique({ where: { id: serverId } });
    if (!server?.containerId) return;

    const stream = await dockerService.attachConsole(server.containerId);
    this.consoleStreams.set(serverId, stream);

    stream.on("data", (chunk: Buffer) => {
      const line = chunk.toString("utf-8");
      this.broadcastToSubscribers(serverId, { event: "console:output", serverId, line, timestamp: Date.now() });
    });
    stream.on("end", () => this.consoleStreams.delete(serverId));
  }

  private ensureStatsPolling(serverId: string) {
    if (this.statsIntervals.has(serverId)) return;

    const interval = setInterval(async () => {
      const server = await prisma.server.findUnique({ where: { id: serverId } });
      if (!server?.containerId) return;
      try {
        const stats = await dockerService.getStats(server.containerId, serverId);
        this.broadcastToSubscribers(serverId, { event: "stats:update", serverId, stats });
      } catch {
        // container likely stopped; polling will self-clear via maybeTeardownStreams
      }
    }, STATS_POLL_INTERVAL_MS);

    this.statsIntervals.set(serverId, interval);
  }

  private broadcastToSubscribers(serverId: string, message: WsServerMessage) {
    for (const client of this.clients) {
      if (client.subscriptions.has(serverId)) this.send(client, message);
    }
  }

  private async handleConsoleCommand(client: Client, serverId: string, command: string) {
    const allowed = await this.assertAccess(client, serverId, "console:write");
    if (!allowed) return this.send(client, { event: "error", message: "No permission to send commands" });

    const server = await prisma.server.findUnique({ where: { id: serverId } });
    if (!server?.containerId) return this.send(client, { event: "error", message: "Server container not found" });

    await dockerService.sendStdin(server.containerId, command);
  }

  private async handlePowerAction(client: Client, serverId: string, action: "start" | "stop" | "restart" | "kill") {
    const permMap = {
      start: "power:start",
      stop: "power:stop",
      restart: "power:restart",
      kill: "power:kill",
    } as const;
    const allowed = await this.assertAccess(client, serverId, permMap[action]);
    if (!allowed) return this.send(client, { event: "error", message: "No permission for this power action" });

    const server = await prisma.server.findUnique({ where: { id: serverId } });
    if (!server?.containerId) return this.send(client, { event: "error", message: "Server container not found" });

    this.broadcastToSubscribers(serverId, {
      event: "status:update",
      serverId,
      status: action === "stop" ? "STOPPING" : action === "start" ? "STARTING" : "STARTING",
    });

    await dockerService.powerAction(server.containerId, action);

    const newStatus = action === "start" || action === "restart" ? "RUNNING" : "OFFLINE";
    await prisma.server.update({ where: { id: serverId }, data: { status: newStatus } });
    this.broadcastToSubscribers(serverId, { event: "status:update", serverId, status: newStatus });
  }

  private maybeTeardownStreams(serverId: string) {
    const stillSubscribed = [...this.clients].some((c) => c.subscriptions.has(serverId));
    if (stillSubscribed) return;

    const interval = this.statsIntervals.get(serverId);
    if (interval) {
      clearInterval(interval);
      this.statsIntervals.delete(serverId);
    }
    this.consoleStreams.delete(serverId); // underlying docker stream GC'd on next attach
  }

  private handleClose(client: Client) {
    this.clients.delete(client);
    for (const serverId of client.subscriptions) this.maybeTeardownStreams(serverId);
  }
}

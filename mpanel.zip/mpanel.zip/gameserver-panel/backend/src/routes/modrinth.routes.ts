import { Router } from "express";
import { authenticate } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { modrinthService } from "../services/modrinth.service";
import { fileService } from "../services/file.service";
import { prisma } from "../lib/prisma";

const router = Router({ mergeParams: true });
router.use(authenticate);

// GET /api/modrinth/search?q=lithium&loader=fabric&gameVersion=1.21
router.get("/search", async (req, res, next) => {
  try {
    const { q = "", loader, gameVersion, limit, offset } = req.query as Record<string, string>;
    const facets: string[][] = [];
    if (loader) facets.push([`categories:${loader}`]);
    if (gameVersion) facets.push([`versions:${gameVersion}`]);
    const results = await modrinthService.search(q, {
      facets: facets.length ? facets : undefined,
      limit: limit ? parseInt(limit) : undefined,
      offset: offset ? parseInt(offset) : undefined,
    });
    res.json(results);
  } catch (err) {
    next(err);
  }
});

router.get("/project/:idOrSlug", async (req, res, next) => {
  try {
    res.json(await modrinthService.getProject(req.params.idOrSlug));
  } catch (err) {
    next(err);
  }
});

router.get("/project/:idOrSlug/versions", async (req, res, next) => {
  try {
    const { loader, gameVersion } = req.query as Record<string, string>;
    res.json(
      await modrinthService.getVersions(req.params.idOrSlug, {
        loaders: loader ? [loader] : undefined,
        gameVersions: gameVersion ? [gameVersion] : undefined,
      })
    );
  } catch (err) {
    next(err);
  }
});

// POST /api/servers/:serverId/modrinth/install  { versionId, targetDir }
router.post("/:serverId/install", requirePermission("plugins:install"), async (req, res, next) => {
  try {
    const { versionId, targetDir = "/plugins" } = req.body as { versionId: string; targetDir?: string };
    const server = await prisma.server.findUniqueOrThrow({ where: { id: req.params.serverId } });

    const file = await modrinthService.getVersionFile(versionId);
    const buffer = await modrinthService.downloadVersionFile(file.url);
    await fileService.saveUpload(server.uuid, `${targetDir}/${file.filename}`, buffer);

    res.status(201).json({ success: true, installedFile: file.filename });
  } catch (err) {
    next(err);
  }
});

export default router;

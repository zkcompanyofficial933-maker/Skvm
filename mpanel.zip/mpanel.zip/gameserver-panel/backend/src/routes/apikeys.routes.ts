import { Router } from "express";
import crypto from "crypto";
import bcrypt from "bcryptjs";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { authenticate } from "../middleware/auth";
import type { Permission } from "../types";

const router = Router();
router.use(authenticate);

router.get("/", async (req, res, next) => {
  try {
    const keys = await prisma.apiKey.findMany({
      where: { userId: req.user!.id },
      select: { id: true, name: true, keyPrefix: true, scopes: true, lastUsedAt: true, createdAt: true, revokedAt: true },
    });
    res.json({ keys: keys.map((k) => ({ ...k, scopes: JSON.parse(k.scopes) })) });
  } catch (err) {
    next(err);
  }
});

const createSchema = z.object({ name: z.string().min(2), scopes: z.array(z.string()) });

// POST /api/api-keys — returns the raw key ONCE; only the hash is persisted
router.post("/", async (req, res, next) => {
  try {
    const body = createSchema.parse(req.body) as { name: string; scopes: Permission[] };
    const rawKey = `gsp_${crypto.randomBytes(24).toString("hex")}`;
    const keyPrefix = rawKey.slice(0, 12);
    const keyHash = await bcrypt.hash(rawKey, 10);

    const key = await prisma.apiKey.create({
      data: { userId: req.user!.id, name: body.name, keyPrefix, keyHash, scopes: JSON.stringify(body.scopes) },
    });

    res.status(201).json({ id: key.id, rawKey, keyPrefix, name: key.name, scopes: body.scopes });
  } catch (err) {
    next(err);
  }
});

router.delete("/:id", async (req, res, next) => {
  try {
    await prisma.apiKey.update({ where: { id: req.params.id }, data: { revokedAt: new Date() } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

export default router;

import { Router } from "express";
import { authenticate } from "../middleware/auth";

const router = Router();
router.use(authenticate);

// Catalog of supported Minecraft server types, all served by the itzg/minecraft-server
// Docker image via the TYPE env var. GET /api/templates/minecraft
router.get("/minecraft", (_req, res) => {
  res.json({
    image: "itzg/minecraft-server",
    versions: ["1.21.1", "1.20.6", "1.20.1", "1.19.4", "1.18.2", "1.16.5"],
    types: [
      { id: "VANILLA", label: "Vanilla", description: "Official Mojang server, no mods or plugins." },
      { id: "PAPER", label: "Paper", description: "High-performance fork with a plugin API. Most popular choice." },
      { id: "SPIGOT", label: "Spigot", description: "Plugin-compatible, CraftBukkit-based server." },
      { id: "FABRIC", label: "Fabric", description: "Lightweight modding platform." },
      { id: "FORGE", label: "Forge", description: "The classic modding platform for heavier modpacks." },
      { id: "PURPUR", label: "Purpur", description: "Paper fork with extra gameplay features & config options." },
    ],
  });
});

export default router;

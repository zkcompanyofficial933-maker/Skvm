import { Router } from "express";
import multer from "multer";
import { z } from "zod";
import { prisma } from "../lib/prisma";
import { authenticate } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { fileService } from "../services/file.service";

const router = Router({ mergeParams: true });
router.use(authenticate);

const upload = multer({ storage: multer.memoryStorage(), limits: { fileSize: 1024 * 1024 * 1024 } }); // 1GB

async function serverUuidFor(serverId: string): Promise<string> {
  const server = await prisma.server.findUniqueOrThrow({ where: { id: serverId } });
  return server.uuid;
}

// GET /api/servers/:serverId/files?path=/
router.get("/", requirePermission("files:read"), async (req, res, next) => {
  try {
    const uuid = await serverUuidFor(req.params.serverId);
    const relPath = (req.query.path as string) ?? "/";
    const nodes = await fileService.listDirectory(uuid, relPath);
    res.json({ path: relPath, files: nodes });
  } catch (err) {
    next(err);
  }
});

// GET /api/servers/:serverId/files/content?path=/server.properties
router.get("/content", requirePermission("files:read"), async (req, res, next) => {
  try {
    const uuid = await serverUuidFor(req.params.serverId);
    const content = await fileService.readFile(uuid, req.query.path as string);
    res.json({ content });
  } catch (err) {
    next(err);
  }
});

// PUT /api/servers/:serverId/files/content  { path, content }
const writeSchema = z.object({ path: z.string(), content: z.string() });
router.put("/content", requirePermission("files:write"), async (req, res, next) => {
  try {
    const uuid = await serverUuidFor(req.params.serverId);
    const body = writeSchema.parse(req.body);
    await fileService.writeFile(uuid, body.path, body.content);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// POST /api/servers/:serverId/files/upload — multipart/form-data, field "file"
router.post("/upload", requirePermission("files:write"), upload.single("file"), async (req, res, next) => {
  try {
    const uuid = await serverUuidFor(req.params.serverId);
    const destPath = ((req.query.path as string) ?? "/") + "/" + req.file!.originalname;
    await fileService.saveUpload(uuid, destPath, req.file!.buffer);
    res.status(201).json({ success: true, path: destPath });
  } catch (err) {
    next(err);
  }
});

const renameSchema = z.object({ from: z.string(), to: z.string() });
router.post("/rename", requirePermission("files:write"), async (req, res, next) => {
  try {
    const uuid = await serverUuidFor(req.params.serverId);
    const body = renameSchema.parse(req.body);
    await fileService.rename(uuid, body.from, body.to);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

router.post("/move", requirePermission("files:write"), async (req, res, next) => {
  try {
    const uuid = await serverUuidFor(req.params.serverId);
    const body = renameSchema.parse(req.body);
    await fileService.move(uuid, body.from, body.to);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

const mkdirSchema = z.object({ path: z.string() });
router.post("/mkdir", requirePermission("files:write"), async (req, res, next) => {
  try {
    const uuid = await serverUuidFor(req.params.serverId);
    const body = mkdirSchema.parse(req.body);
    await fileService.mkdir(uuid, body.path);
    res.status(201).json({ success: true });
  } catch (err) {
    next(err);
  }
});

router.delete("/", requirePermission("files:delete"), async (req, res, next) => {
  try {
    const uuid = await serverUuidFor(req.params.serverId);
    await fileService.delete(uuid, req.query.path as string);
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

const archiveSchema = z.object({ path: z.string(), archiveName: z.string() });
router.post("/compress", requirePermission("files:write"), async (req, res, next) => {
  try {
    const uuid = await serverUuidFor(req.params.serverId);
    const body = archiveSchema.parse(req.body);
    const archive = await fileService.compress(uuid, body.path, body.archiveName);
    res.status(201).json({ archive });
  } catch (err) {
    next(err);
  }
});

const extractSchema = z.object({ archivePath: z.string(), destPath: z.string().default("/") });
router.post("/extract", requirePermission("files:write"), async (req, res, next) => {
  try {
    const uuid = await serverUuidFor(req.params.serverId);
    const body = extractSchema.parse(req.body);
    await fileService.extract(uuid, body.archivePath, body.destPath);
    res.json({ success: true });
  } catch (err) {
    next(err);
  }
});

// GET /api/servers/:serverId/files/sftp-credentials
router.get("/sftp-credentials", requirePermission("files:sftp"), async (req, res, next) => {
  try {
    const server = await prisma.server.findUniqueOrThrow({ where: { id: req.params.serverId } });
    res.json({
      host: server.nodeId, // resolved to node FQDN client-side / via node lookup
      port: process.env.SFTP_PORT ?? 2022,
      username: `${req.user!.username}.${server.uuid.slice(0, 8)}`,
      note: "Use your panel account password to authenticate over SFTP.",
    });
  } catch (err) {
    next(err);
  }
});

export default router;

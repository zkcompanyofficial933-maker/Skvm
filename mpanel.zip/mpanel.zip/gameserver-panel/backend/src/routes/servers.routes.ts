import { Router } from "express";
import { z } from "zod";
import { v4 as uuid } from "uuid";
import { prisma } from "../lib/prisma";
import { authenticate, requireAdmin } from "../middleware/auth";
import { requirePermission } from "../middleware/permissions";
import { dockerService } from "../services/docker.service";
import { fileService } from "../services/file.service";
import { env } from "../config/env";

const router = Router();
router.use(authenticate);

const createServerSchema = z.object({
  name: z.string().min(2),
  description: z.string().optional(),
  nodeId: z.string(),
  image: z.string(),
  dockerImageTag: z.string().default("latest"),
  memoryLimitMb: z.number().int().positive(),
  cpuLimitCores: z.number().positive(),
  diskLimitMb: z.number().int().positive(),
  startupCommand: z.string(),
  environment: z.record(z.string()).default({}),
  primaryPort: z.number().int(),
  additionalPorts: z.array(z.number().int()).default([]),
  ownerId: z.string().optional(), // admin can assign to another user
});

// GET /api/servers — list servers the caller owns, has sub-user access to, or all (if admin)
router.get("/", async (req, res, next) => {
  try {
    const user = req.user!;
    const servers =
      user.role === "ADMIN"
        ? await prisma.server.findMany({ include: { node: true } })
        : await prisma.server.findMany({
            where: {
              OR: [{ ownerId: user.id }, { subUsers: { some: { userId: user.id } } }],
            },
            include: { node: true },
          });
    res.json({ servers });
  } catch (err) {
    next(err);
  }
});

// GET /api/servers/:id
router.get("/:id", requirePermission("console:read"), async (req, res, next) => {
  try {
    const server = await prisma.server.findUnique({
      where: { id: req.params.id },
      include: { node: true, backups: true, tunnels: true },
    });
    if (!server) return res.status(404).json({ error: "Server not found" });
    res.json({ server });
  } catch (err) {
    next(err);
  }
});

// POST /api/servers — admin creates + provisions a new game server container
router.post("/", requireAdmin, async (req, res, next) => {
  try {
    const body = createServerSchema.parse(req.body);
    const node = await prisma.node.findUnique({ where: { id: body.nodeId } });
    if (!node) return res.status(404).json({ error: "Node not found" });

    const serverUuid = uuid();
    await fileService.ensureRoot(serverUuid);
    const volumePath = `${env.DATA_ROOT}/${serverUuid}`;

    const server = await prisma.server.create({
      data: {
        uuid: serverUuid,
        name: body.name,
        description: body.description,
        status: "INSTALLING",
        image: body.image,
        dockerImageTag: body.dockerImageTag,
        memoryLimitMb: body.memoryLimitMb,
        cpuLimitCores: body.cpuLimitCores,
        diskLimitMb: body.diskLimitMb,
        startupCommand: body.startupCommand,
        environment: JSON.stringify(body.environment),
        nodeId: body.nodeId,
        ownerId: body.ownerId ?? req.user!.id,
        primaryPort: body.primaryPort,
        additionalPorts: JSON.stringify(body.additionalPorts),
      },
    });

    const container = await dockerService.createServerContainer({
      name: `gsp-${server.uuid}`,
      image: `${body.image}:${body.dockerImageTag}`,
      envVars: body.environment,
      memoryLimitMb: body.memoryLimitMb,
      cpuCores: body.cpuLimitCores,
      diskLimitMb: body.diskLimitMb,
      primaryPort: body.primaryPort,
      additionalPorts: body.additionalPorts,
      volumePath,
      startupCommand: body.startupCommand,
    });

    const updated = await prisma.server.update({
      where: { id: server.id },
      data: { containerId: container.id, status: "OFFLINE" },
    });

    res.status(201).json({ server: updated });
  } catch (err) {
    next(err);
  }
});

// PATCH /api/servers/:id — update resource limits / metadata
router.patch("/:id", requirePermission("settings:update"), async (req, res, next) => {
  try {
    const server = await prisma.server.update({
      where: { id: req.params.id },
      data: req.body,
    });
    res.json({ server });
  } catch (err) {
    next(err);
  }
});

// DELETE /api/servers/:id
router.delete("/:id", requireAdmin, async (req, res, next) => {
  try {
    const server = await prisma.server.findUnique({ where: { id: req.params.id } });
    if (!server) return res.status(404).json({ error: "Server not found" });
    if (server.containerId) await dockerService.removeContainer(server.containerId).catch(() => {});
    await prisma.server.delete({ where: { id: req.params.id } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

// POST /api/servers/:id/power  { action: "start"|"stop"|"restart"|"kill" }
const powerSchema = z.object({ action: z.enum(["start", "stop", "restart", "kill"]) });
router.post("/:id/power", async (req, res, next) => {
  try {
    const { action } = powerSchema.parse(req.body);
    const permMap = { start: "power:start", stop: "power:stop", restart: "power:restart", kill: "power:kill" } as const;
    // Inline permission check (mirrors middleware/permissions.ts) so we can read `action` first
    const server = await prisma.server.findUnique({ where: { id: req.params.id } });
    if (!server) return res.status(404).json({ error: "Server not found" });
    if (req.user!.role !== "ADMIN" && server.ownerId !== req.user!.id) {
      const subUser = await prisma.subUser.findUnique({
        where: { userId_serverId: { userId: req.user!.id, serverId: server.id } },
      });
      const perms = subUser ? JSON.parse(subUser.permissions) : [];
      if (!subUser || !perms.includes(permMap[action])) {
        return res.status(403).json({ error: "Missing permission for this power action" });
      }
    }
    if (!server.containerId) return res.status(400).json({ error: "Server has no provisioned container" });

    await dockerService.powerAction(server.containerId, action);
    const status = action === "start" || action === "restart" ? "RUNNING" : "OFFLINE";
    const updated = await prisma.server.update({ where: { id: server.id }, data: { status } });
    res.json({ server: updated });
  } catch (err) {
    next(err);
  }
});

// GET /api/servers/:id/sub-users
router.get("/:id/sub-users", requirePermission("settings:update"), async (req, res, next) => {
  try {
    const subUsers = await prisma.subUser.findMany({
      where: { serverId: req.params.id },
      include: { user: { select: { id: true, email: true, username: true } } },
    });
    res.json({
      subUsers: subUsers.map((s) => ({ ...s, permissions: JSON.parse(s.permissions) })),
    });
  } catch (err) {
    next(err);
  }
});

// PUT /api/servers/:id/sub-users — add/update a sub-user's permission matrix
const subUserSchema = z.object({ userId: z.string(), permissions: z.array(z.string()) });
router.put("/:id/sub-users", requirePermission("settings:update"), async (req, res, next) => {
  try {
    const body = subUserSchema.parse(req.body);
    const subUser = await prisma.subUser.upsert({
      where: { userId_serverId: { userId: body.userId, serverId: req.params.id } },
      update: { permissions: JSON.stringify(body.permissions) },
      create: { userId: body.userId, serverId: req.params.id, permissions: JSON.stringify(body.permissions) },
    });
    res.json({ subUser: { ...subUser, permissions: JSON.parse(subUser.permissions) } });
  } catch (err) {
    next(err);
  }
});

router.delete("/:id/sub-users/:userId", requirePermission("settings:update"), async (req, res, next) => {
  try {
    await prisma.subUser.delete({
      where: { userId_serverId: { userId: req.params.userId, serverId: req.params.id } },
    });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

export default router;

import { Router } from "express";
import { z } from "zod";
import crypto from "crypto";
import { prisma } from "../lib/prisma";
import { authenticate, requireAdmin } from "../middleware/auth";
import Docker from "dockerode";

const router = Router();
router.use(authenticate, requireAdmin); // Node management is admin-only

// GET /api/nodes
router.get("/", async (_req, res, next) => {
  try {
    const nodes = await prisma.node.findMany({ include: { servers: true } });
    res.json({ nodes });
  } catch (err) {
    next(err);
  }
});

// GET /api/nodes/:id/health — live daemon ping via Docker Engine API
router.get("/:id/health", async (req, res, next) => {
  try {
    const node = await prisma.node.findUniqueOrThrow({ where: { id: req.params.id } });
    const docker = new Docker({ socketPath: node.dockerSocket });
    const info = await docker.info().catch(() => null);
    const status = info ? "ONLINE" : "OFFLINE";
    await prisma.node.update({ where: { id: node.id }, data: { status } });
    res.json({ status, dockerInfo: info });
  } catch (err) {
    next(err);
  }
});

const createNodeSchema = z.object({
  name: z.string().min(2),
  fqdn: z.string(),
  dockerSocket: z.string().default("/var/run/docker.sock"),
  memoryTotalMb: z.number().int().positive(),
  diskTotalMb: z.number().int().positive(),
  cpuCores: z.number().int().positive(),
  portRangeStart: z.number().int(),
  portRangeEnd: z.number().int(),
  location: z.string().optional(),
});

// POST /api/nodes — register a new host node, generates a daemon token for agent auth
router.post("/", async (req, res, next) => {
  try {
    const body = createNodeSchema.parse(req.body);
    const daemonToken = crypto.randomBytes(32).toString("hex");
    const node = await prisma.node.create({
      data: { ...body, daemonToken, status: "OFFLINE" },
    });
    res.status(201).json({ node, daemonToken });
  } catch (err) {
    next(err);
  }
});

router.patch("/:id", async (req, res, next) => {
  try {
    const node = await prisma.node.update({ where: { id: req.params.id }, data: req.body });
    res.json({ node });
  } catch (err) {
    next(err);
  }
});

router.delete("/:id", async (req, res, next) => {
  try {
    await prisma.node.delete({ where: { id: req.params.id } });
    res.status(204).send();
  } catch (err) {
    next(err);
  }
});

// POST /api/nodes/:id/rotate-token — invalidate + reissue the daemon token
router.post("/:id/rotate-token", async (req, res, next) => {
  try {
    const daemonToken = crypto.randomBytes(32).toString("hex");
    const node = await prisma.node.update({ where: { id: req.params.id }, data: { daemonToken } });
    res.json({ daemonToken: node.daemonToken });
  } catch (err) {
    next(err);
  }
});

export default router;

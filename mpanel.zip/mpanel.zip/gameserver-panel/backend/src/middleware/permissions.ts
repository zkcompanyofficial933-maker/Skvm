import { Request, Response, NextFunction } from "express";
import { prisma } from "../lib/prisma";
import type { Permission } from "../types";

/**
 * Ensures the authenticated user either owns the target server, is an ADMIN,
 * or holds the required permission as a sub-user on that server.
 * Expects `req.params.serverId` (or `id`) to identify the server.
 */
export function requirePermission(permission: Permission) {
  return async (req: Request, res: Response, next: NextFunction) => {
    try {
      const serverId = req.params.serverId ?? req.params.id;
      if (!req.user) return res.status(401).json({ error: "Unauthenticated" });
      if (req.user.role === "ADMIN") return next();

      const server = await prisma.server.findUnique({ where: { id: serverId } });
      if (!server) return res.status(404).json({ error: "Server not found" });

      if (server.ownerId === req.user.id) return next();

      const subUser = await prisma.subUser.findUnique({
        where: { userId_serverId: { userId: req.user.id, serverId } },
      });
      if (!subUser) return res.status(403).json({ error: "No access to this server" });

      const perms: Permission[] = JSON.parse(subUser.permissions);
      if (!perms.includes(permission)) {
        return res.status(403).json({ error: `Missing permission: ${permission}` });
      }
      next();
    } catch (err) {
      next(err);
    }
  };
}

import dotenv from "dotenv";
dotenv.config();

function required(name: string, fallback?: string): string {
  const val = process.env[name] ?? fallback;
  if (val === undefined) {
    throw new Error(`Missing required environment variable: ${name}`);
  }
  return val;
}

export const env = {
  NODE_ENV: process.env.NODE_ENV ?? "development",
  PORT: parseInt(process.env.PORT ?? "8080", 10),
  DATABASE_URL: required("DATABASE_URL", "file:./dev.db"),
  JWT_SECRET: required("JWT_SECRET", "dev_secret_change_me"),
  JWT_EXPIRES_IN: process.env.JWT_EXPIRES_IN ?? "7d",
  DOCKER_SOCKET: process.env.DOCKER_SOCKET ?? "/var/run/docker.sock",
  DAEMON_TOKEN: process.env.DAEMON_TOKEN ?? "dev_daemon_token",
  MODRINTH_API_BASE: process.env.MODRINTH_API_BASE ?? "https://api.modrinth.com/v2",
  PLAYIT_API_BASE: process.env.PLAYIT_API_BASE ?? "https://api.playit.gg",
  CORS_ORIGIN: process.env.CORS_ORIGIN ?? "http://localhost:5173",
  SFTP_PORT: parseInt(process.env.SFTP_PORT ?? "2022", 10),
  DATA_ROOT: process.env.DATA_ROOT ?? "/srv/gsp/volumes",
};

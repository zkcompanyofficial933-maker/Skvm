import express, { Request, Response, NextFunction } from "express";
import http from "http";
import cors from "cors";
import helmet from "helmet";
import compression from "compression";
import rateLimit from "express-rate-limit";
import { env } from "./config/env";
import { logger } from "./utils/logger";
import { WebSocketGateway } from "./websocket/gateway";

import authRoutes from "./routes/auth.routes";
import serverRoutes from "./routes/servers.routes";
import fileRoutes from "./routes/files.routes";
import nodeRoutes from "./routes/nodes.routes";
import modrinthRoutes from "./routes/modrinth.routes";
import userRoutes from "./routes/users.routes";
import apiKeyRoutes from "./routes/apikeys.routes";
import templateRoutes from "./routes/templates.routes";

const app = express();
const httpServer = http.createServer(app);

// ---- Global middleware ----
app.use(helmet());
app.use(cors({ origin: env.CORS_ORIGIN, credentials: true }));
app.use(compression());
app.use(express.json({ limit: "10mb" }));
app.use(express.urlencoded({ extended: true }));

const apiLimiter = rateLimit({ windowMs: 60_000, max: 300 }); // 300 req/min/IP
app.use("/api", apiLimiter);

app.use((req: Request, _res: Response, next: NextFunction) => {
  logger.debug(`${req.method} ${req.originalUrl}`);
  next();
});

// ---- Health check ----
app.get("/health", (_req, res) => res.json({ status: "ok", timestamp: Date.now() }));

// ---- Routes ----
app.use("/api/auth", authRoutes);
app.use("/api/servers", serverRoutes);
app.use("/api/servers/:serverId/files", fileRoutes);
app.use("/api/servers/:serverId/modrinth", modrinthRoutes);
app.use("/api/modrinth", modrinthRoutes);
app.use("/api/nodes", nodeRoutes);
app.use("/api/users", userRoutes);
app.use("/api/api-keys", apiKeyRoutes);
app.use("/api/templates", templateRoutes);

// ---- 404 handler ----
app.use((req, res) => {
  res.status(404).json({ error: `Route not found: ${req.method} ${req.originalUrl}` });
});

// ---- Global error handler ----
app.use((err: any, _req: Request, res: Response, _next: NextFunction) => {
  logger.error("Unhandled error", err);
  if (err?.name === "ZodError") {
    return res.status(400).json({ error: "Validation failed", details: err.errors });
  }
  const status = err?.status ?? 500;
  res.status(status).json({ error: err?.message ?? "Internal server error" });
});

// ---- WebSocket gateway (console streaming, live stats, power actions) ----
new WebSocketGateway(httpServer);

httpServer.listen(env.PORT, () => {
  logger.info(`GSP backend listening on port ${env.PORT} [${env.NODE_ENV}]`);
  logger.info(`WebSocket gateway available at ws://localhost:${env.PORT}/ws`);
});

process.on("unhandledRejection", (reason) => logger.error("Unhandled promise rejection", reason));
process.on("SIGTERM", () => {
  logger.info("SIGTERM received, shutting down gracefully");
  httpServer.close(() => process.exit(0));
});

export default app;

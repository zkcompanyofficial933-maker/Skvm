# NovaPanel — Minecraft Server Hosting Panel

A full-stack, self-hosted game server management panel (Pterodactyl-style) purpose-built
for **Minecraft server hosting**, using Docker containers for full process isolation.

---

## Architecture

```
gameserver-panel/
├── backend/                 # Node.js + TypeScript API & WebSocket daemon
│   ├── prisma/schema.prisma # Users, Nodes, Servers, SubUsers, Backups, ApiKeys, Tunnels
│   └── src/
│       ├── server.ts        # Express entry point
│       ├── websocket/       # Real-time console + stats gateway
│       ├── services/        # Docker, FileSystem, Modrinth, Tunnel (playit.gg), SFTP
│       ├── routes/          # auth, servers, files, nodes, modrinth, users, api-keys
│       └── middleware/      # JWT auth + granular permission checks
├── frontend/                 # React 18 + TypeScript + Tailwind (Vite)
│   └── src/
│       ├── pages/            # Dashboard, Nodes, Users, API Keys, Login
│       ├── pages/server/     # Console, Files, Players, Plugins, World, Tunnel, Sub-Users
│       ├── components/       # Sidebar, Header (Cmd+K search), UI primitives
│       └── hooks/            # useServerSocket (WebSocket console/stats hook)
└── docker-compose.yml         # One-command full-stack deployment
```

## How it actually hosts a Minecraft server

Every server is a real, isolated Docker container running the battle-tested
[`itzg/minecraft-server`](https://github.com/itzg/docker-minecraft-server) image, which
supports Vanilla, Paper, Spigot, Fabric, Forge, and Purpur out of the box via a single
`TYPE` environment variable. When you click **Deploy server** in the panel:

1. The backend creates a Prisma `Server` record and a scoped data directory on disk.
2. `dockerode` creates a container with your chosen memory/CPU limits, exposes the
   Minecraft port, and mounts the data directory to `/data` inside the container.
3. The WebSocket gateway attaches to the container's stdio, so console output streams
   live into the panel's `xterm.js` terminal, and commands you type are written back to
   the container's stdin — exactly like being at the machine.
4. Stats (CPU/RAM/network) are polled from the Docker Engine API every 2 seconds.

## Running it locally (development)

**Requirements:** Node.js 20+, Docker Engine running locally, and the Docker socket
accessible to the backend process.

```bash
# 1. Backend
cd backend
cp .env.example .env          # edit JWT_SECRET, DATA_ROOT, etc.
npm install
npx prisma migrate dev --name init
npm run dev                   # http://localhost:8080

# 2. Frontend (in a second terminal)
cd frontend
npm install
npm run dev                   # http://localhost:5173
```

Open `http://localhost:5173`, register an account (the **first** registered user
automatically becomes ADMIN), register a host node pointing at your local Docker
socket (`/var/run/docker.sock`), then create your first Minecraft server.

## Running it in production (Docker Compose)

```bash
export JWT_SECRET=$(openssl rand -hex 32)
docker compose up -d --build
```

This brings up the backend (bound to the host's Docker socket so it can create
sibling game-server containers), a Postgres database, and the built frontend served
via nginx. Swap `DATABASE_URL`/`provider` in `prisma/schema.prisma` if you'd rather
run SQLite for a small single-node install.

## Bun / PM2

The backend runs equally well under Bun (`bun run src/server.ts`) or as a managed
PM2 process (`pm2 start ecosystem.config.js`) if you're not containerizing the panel
itself — only the game servers need to be containerized.

## Feature checklist

- [x] Docker container lifecycle (create / start / stop / restart / kill)
- [x] Dynamic resource limits (RAM, CPU cores, disk, ports)
- [x] Live interactive console over WebSocket (xterm.js)
- [x] Real-time CPU/RAM/network/uptime stats
- [x] File manager: browse, edit, upload (drag & drop), rename, delete, compress/extract
- [x] SFTP bridge scaffold for FileZilla/Cyberduck (`services/sftp.service.ts`)
- [x] Modrinth integration: search, version listing, one-click install
- [x] World manager: world switcher + backup/restore via compress/extract
- [x] playit.gg tunnel management scaffold
- [x] JWT auth, ADMIN vs USER roles, granular per-server sub-user permission matrix
- [x] API key generator with scoped permissions
- [x] Host node registry with daemon tokens + live health checks
- [x] Dashboard, quick-search (Cmd+K), collapsible sidebar, dark glassmorphism UI

## Notes on hardening before real-world production use

- Disk quotas: the compose file mounts a shared volume; for real per-server disk caps,
  back `DATA_ROOT` with a filesystem that supports project quotas (XFS `pquota`) or use
  per-server loopback volumes.
- The SFTP bridge in this repo is a scaffold showing the auth handshake and chroot
  resolution — wire in `ssh2-sftp-server`'s stream handlers for a fully functional
  subsystem, or swap in a battle-tested SFTP-to-filesystem library.
- Rotate `JWT_SECRET` and `DAEMON_TOKEN`s outside of source control (use a secrets
  manager in production).
